import tkinter as tk
from tkinter import ttk, messagebox
import pyodbc

# --- HẰNG SỐ MÀU SẮC ĐỒNG BỘ TỪ CANVAS CHÍNH ---
MAU_NEN_CHINH = "#0f1720"      # BG
MAU_NEN_MENU = "#132233"     # SIDEBAR_BG
MAU_NEN_KHUNG = "#172433"   # PANEL_BG
MAU_NHAN = "#66AEE9"             # ACCENT
MAU_NUT_NEN = "#25455e"         # BTN_BG
MAU_NUT_HOVER = "#3a6f8e"   # BTN_ACTIVE
MAU_CHU_CHINH = "#eaf2fb"   # TEXT
MAU_NEN_NHAP = "#2b3d47"     # INPUT_BG
MAU_NUT_THOAT = "#F85B50"   # ERROR_BTN

FONT_TIEU_DE_LON = ("Segoe UI", 20, "bold")
FONT_NHAN = ("Segoe UI", 10)
FONT_NUT = ("Segoe UI", 10, "bold")
# ===============================================

def canh_giua_cua_so(win, w=400, h=300):
    win.update_idletasks()
    ws = win.winfo_screenwidth()
    hs = win.winfo_screenheight()
    x = (ws // 2) - (w // 2)
    y = (hs // 2) - (h // 2)
    win.geometry(f'{w}x{h}+{x}+{y}')

def MoFormLogin(master_window, success_callback):
    cua_so_login = tk.Toplevel()    
    cua_so_login.title("Đăng nhập Hệ thống")
    cua_so_login.config(bg=MAU_NEN_CHINH)
    canh_giua_cua_so(cua_so_login, 450, 400)
    cua_so_login.resizable(False, False)

    cua_so_login.transient(master_window)
    cua_so_login.grab_set()

    def on_closing():
        if messagebox.askyesno("Xác nhận", "Bạn có muốn thoát toàn bộ ứng dụng?"):
            master_window.quit() # Thoát toàn bộ ứng dụng gốc
            
    cua_so_login.protocol("WM_DELETE_WINDOW", on_closing) 

    # Biến lưu trữ thông tin
    ten_dang_nhap = tk.StringVar()
    mat_khau = tk.StringVar()

    def xu_ly_dang_nhap():
        user = ten_dang_nhap.get()
        password = mat_khau.get()

        if user == "admin" and password == "123":
            cua_so_login.destroy()
            # 2. Gọi hàm callback để hiện lại Trang Chủ
            success_callback() 
        else:
            messagebox.showerror("Lỗi đăng nhập", "Tên đăng nhập hoặc mật khẩu không đúng.")

    # KHUNG CHỨA
    khung_chinh = tk.Frame(cua_so_login, bg=MAU_NEN_KHUNG, padx=20, pady=30, bd=1, relief=tk.FLAT)
    khung_chinh.pack(padx=30, pady=30, fill="both", expand=True)

    # Tiêu đề
    tk.Label(khung_chinh, text="ĐĂNG NHẬP HỆ THỐNG", font=FONT_TIEU_DE_LON, 
             bg=MAU_NEN_KHUNG, fg=MAU_NHAN).pack(pady=(0, 20))

    # Tên đăng nhập
    tao_nhan(khung_chinh, "Tên đăng nhập:", 0, 0, bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH).pack(anchor="w", pady=(10, 2))
    tao_o_nhap(khung_chinh, ten_dang_nhap, 40, 1, 0).pack(fill="x", ipady=4)
    
    # Mật khẩu
    tao_nhan(khung_chinh, "Mật khẩu:", 0, 0, bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH).pack(anchor="w", pady=(10, 2))
    tao_o_nhap(khung_chinh, mat_khau, 40, 1, 0, show="*").pack(fill="x", ipady=4)

    # Nút Đăng nhập
    tk.Button(khung_chinh, text="ĐĂNG NHẬP", font=FONT_NUT, bg=MAU_NUT_NEN, 
              fg=MAU_CHU_CHINH, relief="flat", width=15, 
              activebackground=MAU_NUT_HOVER, activeforeground="white",
              command=xu_ly_dang_nhap).pack(pady=20)
    
    # Nút Thoát
    tk.Button(khung_chinh, text="THOÁT", font=("Segoe UI", 9), bg=MAU_NUT_THOAT, 
              fg=MAU_CHU_CHINH, relief="flat", width=10, 
              activebackground="#D44D4D", activeforeground="white",
              command=cua_so_login.quit).pack()

    cua_so_login.mainloop()

def tao_nhan(parent, text, r, c, bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH):
    return tk.Label(parent, text=text, font=FONT_NHAN, bg=bg, fg=fg)
    
def tao_o_nhap(parent, textvariable, width, r, c, show=""):
    return tk.Entry(parent, textvariable=textvariable, font=FONT_NHAN, width=width,
                    bg=MAU_NEN_NHAP, fg=MAU_CHU_CHINH, insertbackground=MAU_CHU_CHINH, 
                    bd=0, show=show)
