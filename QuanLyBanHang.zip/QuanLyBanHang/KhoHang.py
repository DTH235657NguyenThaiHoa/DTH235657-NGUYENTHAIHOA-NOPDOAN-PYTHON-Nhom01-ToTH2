# ...existing code...
import tkinter as tk
from tkinter import ttk, messagebox
import os
import pyodbc  # BỔ SUNG: Import pyodbc để kết nối CSDL
from datetime import date  # BỔ SUNG: Import date để lấy ngày hiện tại

# BỔ SUNG: Hàm kết nối CSDL, được copy từ các Form khác
def connect():
    """Thiết lập kết nối đến SQL Server."""
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=DESKTOP-DR4Q3K4;'
            'DATABASE=QuanLyBanHang;'
            'Trusted_Connection=yes;'
        )
        return conn
    except Exception as e:
        messagebox.showerror("Lỗi CSDL", f"Không thể kết nối đến SQL Server: {e}")
        return None

# ========== HẰNG SỐ MÀU SẮC ĐỒNG BỘ ========== (GIỮ NGUYÊN NHƯ TRANG CHỦ)
MAU_NEN_CHINH = "#0f1720"   # BG
MAU_NEN_MENU = "#132233"    # SIDEBAR_BG
MAU_NEN_KHUNG = "#172433"   # PANEL_BG
MAU_NEN_BANNER = "#052244"  # BANNER_TOP
MAU_NHAN = "#66AEE9"        # ACCENT
MAU_NUT_NEN = "#25455e"     # BTN_BG
MAU_NUT_HOVER = "#3a6f8e"   # BTN_ACTIVE
MAU_CHU_CHINH = "#eaf2fb"   # TEXT
MAU_NEN_NHAP = "#2b3d47"
MAU_NUT_THOAT = "#F85B50"

FONT_TIEU_DE = ("Segoe UI", 12, "bold")
FONT_PHU = ("Segoe UI", 9)
FONT_ICON = ("Segoe UI Emoji", 24)

# BỔ SUNG: Hàm tiện ích định dạng tiền tệ
def format_currency(value):
    """Định dạng giá trị số thành chuỗi tiền tệ (vd: 1,000,000 VND)."""
    try:
        # Làm tròn và thêm dấu phân cách hàng ngàn
        return f"{int(value):,.0f} VND"
    except (ValueError, TypeError):
        return "0 VND"

# ========= Hàm tiện ích =========
def canh_giua_cua_so(win, w=1000, h=680):
    win.update_idletasks()
    ws = win.winfo_screenwidth()
    hs = win.winfo_screenheight()
    x = (ws // 2) - (w // 2)
    y = (hs // 2) - (h // 2)
    win.geometry(f'{w}x{h}+{x}+{y}')

# ========== Hàm chính để mở form Kho Hàng ==========
def MoFormKhoHang(parent, default_page="LapPhieuNhap"):
    """
    Tạo 1 Toplevel độc lập để quản lý Kho Hàng (Phiếu Nhập, Tồn Kho).
    default_page: "LapPhieuNhap" | "QuanLyPhieuNhap" | "KiemKeTonKho"
    """

    cua_so_con = tk.Toplevel(parent)
    cua_so_con.title("Kho Hàng - Quản lý nhập xuất tồn")
    cua_so_con.config(bg=MAU_NEN_CHINH)
    canh_giua_cua_so(cua_so_con, 1000, 680)
    cua_so_con.resizable(False, False)

    # ========== Styles ==========
    style = ttk.Style()
    try:
        style.theme_use("clam")
    except Exception:
        pass

    # Định nghĩa lại style cho Treeview nếu cần (để đảm bảo đồng bộ)
    st = ttk.Style()
    try:
        st.theme_use("clam")
    except Exception:
        pass
    st.configure(
        "Treeview",
        background=MAU_NEN_KHUNG,
        foreground=MAU_CHU_CHINH,
        fieldbackground=MAU_NEN_KHUNG,
        rowheight=24,
    )
    st.map("Treeview", background=[("selected", MAU_NUT_NEN)])
    st.configure(
        "Treeview.Heading",
        background=MAU_NUT_NEN,
        foreground=MAU_CHU_CHINH,
        font=("Segoe UI", 10, "bold"),
    )

    # ========== LAYOUT: MenuBen & NoiDungChinh ==========
    menu_ben = tk.Frame(cua_so_con, bg=MAU_NEN_MENU, width=200)
    menu_ben.pack(side="left", fill="y")
    noi_dung_chinh = tk.Frame(cua_so_con, bg=MAU_NEN_CHINH)
    noi_dung_chinh.pack(side="left", fill="both", expand=True)

    # ===== MenuBen content (Icon & TenUngDung) =====
    icon_ung_dung = tk.Label(
        menu_ben, text="📦", bg=MAU_NEN_MENU, fg=MAU_NHAN, font=("Segoe UI", 25)
    )
    icon_ung_dung.pack(pady=(18, 6))
    ten_ung_dung = tk.Label(
        menu_ben,
        text="QUẢN LÝ\nKHO HÀNG\n",
        bg=MAU_NEN_MENU,
        fg=MAU_CHU_CHINH,
        font=("Segoe UI", 12, "bold"),
        justify="center",
    )
    ten_ung_dung.pack(pady=(0, 18))
    tieu_de_menu = tk.Label(
        menu_ben,
        text="Chức năng",
        bg=MAU_NEN_MENU,
        fg="#9fb8c9",
        font=("Segoe UI", 9, "bold"),
    )
    tieu_de_menu.pack(anchor="w", padx=20, pady=(6, 2))

    # ====== TẠO CÁC KHUNG NỘI DUNG (PAGE FRAMES) ======
    page_nhap = tk.Frame(noi_dung_chinh, bg=MAU_NEN_CHINH)
    page_qlpn = tk.Frame(noi_dung_chinh, bg=MAU_NEN_CHINH)
    page_tonkho = tk.Frame(noi_dung_chinh, bg=MAU_NEN_CHINH)

    for fr in (page_nhap, page_qlpn, page_tonkho):
        fr.place(relx=0, rely=0, relwidth=1, relheight=1)

    # ===== Sidebar buttons logic =====
    nut_menu = {}

    def dat_trang_thai_hoat_dong(nut_key):
        for k, nut in nut_menu.items():
            nut.config(bg=MAU_NEN_MENU, fg=MAU_CHU_CHINH)
        if nut_key in nut_menu:
            nut_menu[nut_key].config(bg=MAU_NUT_NEN, fg="white")

    def hien_thi_trang(trang):
        trang.tkraise()

    def xu_ly_nhan_menu(key):
        dat_trang_thai_hoat_dong(key)
        if key == "LapPhieuNhap":
            hien_thi_trang(page_nhap)
        elif key == "QuanLyPhieuNhap":
            hien_thi_trang(page_qlpn)
        elif key == "KiemKeTonKho":
            hien_thi_trang(page_tonkho)

    danh_muc_menu = [
        ("LapPhieuNhap", "📝 Lập Phiếu Nhập"),
        ("QuanLyPhieuNhap", "📦 Quản lý Phiếu Nhập"),
        ("KiemKeTonKho", "📊 Kiểm kê Tồn kho"),
    ]

    for k, nhan in danh_muc_menu:
        nut = tk.Button(
            menu_ben,
            text=nhan,
            font=("Segoe UI", 11),
            bg=MAU_NEN_MENU,
            fg=MAU_CHU_CHINH,
            activebackground=MAU_NUT_HOVER,
            activeforeground="white",
            bd=0,
            command=lambda key=k: xu_ly_nhan_menu(key),
            anchor="w",
        )
        nut.pack(fill="x", padx=20, pady=6)
        nut_menu[k] = nut

    tk.Frame(menu_ben, bg=MAU_NEN_MENU).pack(fill="both", expand=True)  # spacer
    tk.Button(
        menu_ben,
        text="Đóng",
        font=("Segoe UI", 11, "bold"),
        bg=MAU_NUT_THOAT,
        fg="white",
        bd=0,
        command=cua_so_con.destroy,
    ).pack(fill="x", padx=20, pady=(0, 18))

    # ========== Xây dựng từng trang nội dung ==========
    FONT_TIEU_DE_LON = ("Segoe UI", 16, "bold")
    FONT_NHAN = ("Segoe UI", 10)
    FONT_NUT = ("Segoe UI", 10, "bold")
    FONT_TIEU_DE_NHO = ("Segoe UI", 12, "bold")

    # ------------------ TRANG: LẬP PHIẾU NHẬP ------------------
    def build_lap_phieu_nhap(khung):
        # Biến dữ liệu
        MaPN = tk.StringVar()
        NhaCungCap = tk.StringVar()
        NhanVien = tk.StringVar()
        NgayNhap = tk.StringVar()
        TongGiaTriNhap = tk.StringVar(value="0 VND")  # Tổng giá trị nhập

        # BỔ SUNG: List tạm thời để lưu Chi tiết Phiếu Nhập
        # (TenSP, SoLuongNhap, DonGiaNhap)
        chi_tiet_pn_list = []

        # BỔ SUNG: Hàm cập nhật Treeview Chi tiết PN và tính Tổng tiền
        def cap_nhat_chi_tiet_pn():
            # Xóa dữ liệu cũ
            for item in tree_chitiet.get_children():
                tree_chitiet.delete(item)

            tong_gia_tri = 0
            for sp in chi_tiet_pn_list:
                ten_sp, sl, dg = sp
                thanh_tien = sl * dg
                tong_gia_tri += thanh_tien
                # Thêm vào Treeview
                tree_chitiet.insert("", tk.END, values=(ten_sp, sl, format_currency(dg)))

            TongGiaTriNhap.set(format_currency(tong_gia_tri))

        # BỔ SUNG: Hàm xử lý nút "Thêm sản phẩm"
        def them_san_pham_vao_pn():
            ten_sp = TenSP.get().strip()
            sl_str = SoLuongNhap.get().strip()
            dg_str = DonGiaNhap.get().strip()

            if not ten_sp or not sl_str or not dg_str:
                messagebox.showwarning(
                    "Lỗi nhập liệu", "Vui lòng nhập đầy đủ Tên SP, Số lượng và Đơn giá."
                )
                return

            try:
                sl = int(sl_str)
                # Xử lý định dạng tiền tệ nếu có
                dg = float(dg_str.replace(".", "").replace(",", ""))
                if sl <= 0 or dg <= 0:
                    raise ValueError
            except ValueError:
                messagebox.showwarning(
                    "Lỗi định dạng", "Số lượng và Đơn giá phải là số dương hợp lệ."
                )
                return

            # Thêm vào list tạm thời
            chi_tiet_pn_list.append((ten_sp, sl, dg))

            # Cập nhật UI
            cap_nhat_chi_tiet_pn()

            # Xóa trường nhập liệu SP
            TenSP.set("")
            SoLuongNhap.set("")
            DonGiaNhap.set("")

        # BỔ SUNG: Hàm xử lý nút "Xoá sản phẩm"
        def xoa_san_pham_khoi_pn():
            selected_item = tree_chitiet.selection()
            if not selected_item:
                messagebox.showwarning("Cảnh báo", "Vui lòng chọn sản phẩm cần xóa.")
                return

            # Lấy index của item được chọn trong list tạm
            item_index = tree_chitiet.index(selected_item[0])

            if 0 <= item_index < len(chi_tiet_pn_list):
                chi_tiet_pn_list.pop(item_index)

            # Cập nhật UI
            cap_nhat_chi_tiet_pn()

        # BỔ SUNG: Hàm xử lý nút "Huỷ Phiếu Nhập" (Reset Form)
        def huy_phieu_nhap():
            MaPN.set("")
            NhaCungCap.set("")
            NhanVien.set("")
            NgayNhap.set(date.today().strftime("%Y-%m-%d"))  # Ngày hiện tại
            TongGiaTriNhap.set("0 VND")

            TenSP.set("")
            SoLuongNhap.set("")
            DonGiaNhap.set("")

            chi_tiet_pn_list.clear()
            cap_nhat_chi_tiet_pn()  # Cập nhật Treeview trống

        # BỔ SUNG: Hàm xử lý nút "Lưu Phiếu Nhập" (Ghi vào CSDL)
        def luu_phieu_nhap():
            ma_pn = MaPN.get().strip()
            ma_ncc = NhaCungCap.get().strip()
            ma_nv = NhanVien.get().strip()
            ngay_nhap = NgayNhap.get().strip()

            if not all([ma_pn, ma_ncc, ma_nv, ngay_nhap]):
                messagebox.showwarning(
                    "Lỗi nhập liệu", "Vui lòng nhập đầy đủ Mã PN, Mã NCC, Mã NV và Ngày nhập."
                )
                return

            if not chi_tiet_pn_list:
                messagebox.showwarning("Cảnh báo", "Vui lòng thêm ít nhất một sản phẩm vào phiếu nhập.")
                return

            conn = connect()
            if not conn:
                return
            cursor = conn.cursor()

            try:
                # 1. Lấy MaSP từ TenSP và kiểm tra sự tồn tại của SP
                san_pham_map = {}
                for ten_sp, _, _ in chi_tiet_pn_list:
                    cursor.execute("SELECT MaSP FROM SANPHAM WHERE TenSP = ?", ten_sp)
                    result = cursor.fetchone()
                    if result:
                        san_pham_map[ten_sp] = {"MaSP": result[0]}
                    else:
                        messagebox.showerror(
                            "Lỗi SP", f"Sản phẩm '{ten_sp}' không tìm thấy. Vui lòng thêm sản phẩm trước."
                        )
                        conn.close()
                        return

                # 2. Tính tổng giá trị và chuẩn bị dữ liệu
                chi_tiet_data = []
                tong_gia_tri = 0.0
                for ten_sp, sl, dg in chi_tiet_pn_list:
                    ma_sp = san_pham_map[ten_sp]["MaSP"]
                    thanh_tien = sl * dg
                    tong_gia_tri += thanh_tien
                    chi_tiet_data.append((ma_pn, ma_sp, sl, dg))

                # 3. Insert PHIEUNHAP
                sql_pn = "INSERT INTO PHIEUNHAP (MaPN, MaNCC, MaNV, NgayNhap, TongGiaTriNhap) VALUES (?, ?, ?, ?, ?)"
                cursor.execute(sql_pn, (ma_pn, ma_ncc, ma_nv, ngay_nhap, tong_gia_tri))

                # 4. Insert CHITIETPHIEUNHAP
                sql_ctpn = "INSERT INTO CHITIETPHIEUNHAP (MaPN, MaSP, SoLuongNhap, DonGiaNhap) VALUES (?, ?, ?, ?)"
                cursor.executemany(sql_ctpn, chi_tiet_data)

                # 5. Update Tồn Kho (TonKho) trong SANPHAM
                for ten_sp, sl, dg in chi_tiet_pn_list:
                    ma_sp = san_pham_map[ten_sp]["MaSP"]
                    # Cập nhật tồn kho và Giá vốn mới (theo nghiệp vụ, giá vốn mới là giá nhập cuối)
                    sql_update_sp = "UPDATE SANPHAM SET TonKho = TonKho + ? WHERE MaSP = ?"
                    cursor.execute(sql_update_sp, (sl, ma_sp))

                conn.commit()
                messagebox.showinfo(
                    "Thành công", f"Đã lưu Phiếu Nhập {ma_pn} thành công và cập nhật tồn kho."
                )
                huy_phieu_nhap()  # Reset form

            except pyodbc.IntegrityError as e:
                messagebox.showerror("Lỗi CSDL", f"Lỗi trùng lặp Mã PN hoặc Mã NCC/NV không tồn tại: {e}")
            except Exception as e:
                messagebox.showerror("Lỗi", f"Lỗi khi lưu phiếu nhập: {e}")
                conn.rollback()
            finally:
                conn.close()

        # Tiêu đề
        hdr = tk.Frame(khung, bg=MAU_NEN_CHINH)
        hdr.pack(fill="x", pady=15, padx=20)
        tk.Label(
            hdr,
            text="LẬP PHIẾU NHẬP KHO",
            font=FONT_TIEU_DE_LON,
            bg=MAU_NEN_CHINH,
            fg=MAU_NHAN,
        ).pack(anchor="w")

        # Khung nhập liệu (trái) và chi tiết giao dịch (phải)
        khung_chinh = tk.Frame(khung, bg=MAU_NEN_CHINH)
        khung_chinh.pack(fill="both", expand=True, padx=10, pady=10)

        # Khung LEFT (Phiếu Nhập)
        left = tk.Frame(khung_chinh, bg=MAU_NEN_KHUNG, width=350)
        left.pack(side="left", fill="y", padx=(10, 5), pady=5)
        left.pack_propagate(False)

        right = tk.Frame(khung_chinh, bg=MAU_NEN_KHUNG)
        right.pack(side="left", fill="both", expand=True, padx=(5, 10), pady=5)

        # --- Nội dung left: form đơn giản ---
        form_left = tk.Frame(left, bg=MAU_NEN_KHUNG, padx=10, pady=10)
        form_left.pack(fill="x")
        form_left.columnconfigure(1, weight=1)

        def tao_nhan(k, text, r, c):
            tk.Label(k, text=text, font=FONT_NHAN, bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH).grid(
                row=r, column=c, sticky="w", padx=6, pady=6
            )

        def tao_o(k, var, r, c):
            tk.Entry(
                k,
                textvariable=var,
                width=25,
                font=FONT_NHAN,
                bg=MAU_NEN_NHAP,
                fg=MAU_CHU_CHINH,
                bd=0,
                insertbackground=MAU_CHU_CHINH,
                relief="flat",
            ).grid(row=r, column=c, padx=6, pady=6, sticky="ew")

        # Thông tin Phiếu Nhập
        tao_nhan(form_left, "Mã PN:", 0, 0)
        tao_o(form_left, MaPN, 0, 1)

        tao_nhan(form_left, "Nhà CC:", 2, 0)
        tao_o(form_left, NhaCungCap, 2, 1)

        tao_nhan(form_left, "Nhân viên:", 3, 0)
        tao_o(form_left, NhanVien, 3, 1)

        tao_nhan(form_left, "Ngày nhập:", 4, 0)
        tao_o(form_left, NgayNhap, 4, 1)

        # BỔ SUNG: Thiết lập ngày nhập mặc định là ngày hiện tại
        NgayNhap.set(date.today().strftime("%Y-%m-%d"))

        # Khung nhập chi tiết SP nhập
        frame_chi_tiet = tk.Frame(left, bg=MAU_NEN_KHUNG, pady=10, padx=10)
        frame_chi_tiet.pack(fill="x", pady=(15, 5))

        # Biến tạm cho chi tiết sản phẩm
        TenSP = tk.StringVar()
        SoLuongNhap = tk.StringVar()
        DonGiaNhap = tk.StringVar()

        frame_chi_tiet.columnconfigure(1, weight=1)
        frame_chi_tiet.columnconfigure(3, weight=1)

        tk.Label(
            frame_chi_tiet,
            text="Thêm Sản Phẩm",
            font=FONT_TIEU_DE_NHO,
            bg=MAU_NEN_KHUNG,
            fg=MAU_NHAN,
        ).grid(row=0, column=0, columnspan=4, sticky="w", padx=6, pady=(0, 5))

        tk.Label(
            frame_chi_tiet,
            text="Tên SP:",
            font=FONT_NHAN,
            bg=MAU_NEN_KHUNG,
            fg=MAU_CHU_CHINH,
        ).grid(row=1, column=0, sticky="w", padx=6, pady=2)
        tk.Entry(
            frame_chi_tiet,
            textvariable=TenSP,
            width=20,
            font=FONT_NHAN,
            bg=MAU_NEN_NHAP,
            fg=MAU_CHU_CHINH,
            bd=0,
            relief="flat",
        ).grid(row=1, column=1, columnspan=3, padx=6, pady=2, sticky="ew")

        tk.Label(
            frame_chi_tiet,
            text="SL Nhập:",
            font=FONT_NHAN,
            bg=MAU_NEN_KHUNG,
            fg=MAU_CHU_CHINH,
        ).grid(row=2, column=0, sticky="w", padx=6, pady=2)
        tk.Entry(
            frame_chi_tiet,
            textvariable=SoLuongNhap,
            width=8,
            font=FONT_NHAN,
            bg=MAU_NEN_NHAP,
            fg=MAU_CHU_CHINH,
            bd=0,
            relief="flat",
        ).grid(row=2, column=1, padx=6, pady=2, sticky="ew")

        tk.Label(
            frame_chi_tiet,
            text="Đơn giá:",
            font=FONT_NHAN,
            bg=MAU_NEN_KHUNG,
            fg=MAU_CHU_CHINH,
        ).grid(row=2, column=2, sticky="w", padx=6, pady=2)
        tk.Entry(
            frame_chi_tiet,
            textvariable=DonGiaNhap,
            width=12,
            font=FONT_NHAN,
            bg=MAU_NEN_NHAP,
            fg=MAU_CHU_CHINH,
            bd=0,
            relief="flat",
        ).grid(row=2, column=3, padx=6, pady=2, sticky="ew")

        # Buttons thao tác chi tiết PN
        # BỔ SUNG: Gán command cho các nút
        tk.Button(
            frame_chi_tiet,
            text="Thêm sản phẩm",
            bg=MAU_NUT_NEN,
            fg=MAU_CHU_CHINH,
            font=FONT_NUT,
            width=15,
            activebackground=MAU_NUT_HOVER,
            activeforeground="white",
            bd=0,
            command=them_san_pham_vao_pn,
        ).grid(row=4, column=0, columnspan=2, pady=10, padx=6, sticky="w")
        tk.Button(
            frame_chi_tiet,
            text="Xoá sản phẩm",
            bg=MAU_NUT_NEN,
            fg=MAU_CHU_CHINH,
            font=FONT_NUT,
            width=15,
            activebackground=MAU_NUT_HOVER,
            activeforeground="white",
            bd=0,
            command=xoa_san_pham_khoi_pn,
        ).grid(row=4, column=2, columnspan=2, pady=10, padx=6, sticky="e")

        # Buttons thao tác chính (Lưu/Xóa PN)
        frame_btns_chinh = tk.Frame(left, bg=MAU_NEN_KHUNG, padx=10)
        frame_btns_chinh.pack(fill="x", pady=(15, 10))

        # BỔ SUNG: Gán command cho các nút
        tk.Button(
            frame_btns_chinh,
            text="Lưu Phiếu Nhập",
            bg=MAU_NUT_NEN,
            fg=MAU_CHU_CHINH,
            font=FONT_NUT,
            width=12,
            activebackground=MAU_NUT_HOVER,
            activeforeground="white",
            bd=0,
            command=luu_phieu_nhap,
        ).pack(side="left", padx=6, fill="x", expand=True)

        tk.Button(
            frame_btns_chinh,
            text="Huỷ Phiếu Nhập",
            bg=MAU_NUT_THOAT,
            fg="white",
            font=FONT_NUT,
            width=12,
            activebackground="#a83c34",
            activeforeground="white",
            bd=0,
            command=huy_phieu_nhap,
        ).pack(side="left", padx=6, fill="x", expand=True)

        # --- Nội dung right: Treeview chi tiết sản phẩm nhập ---
        cols = ("Tên SP", "Số lượng", "Đơn giá")
        tree_chitiet = ttk.Treeview(right, columns=cols, show="headings", height=12)

        tree_chitiet.column("#0", width=0, stretch=tk.NO)  # Ẩn cột đầu tiên
        for c in cols:
            tree_chitiet.heading(c, text=c)
            if c == "Tên SP":
                tree_chitiet.column(c, width=180, anchor="w")
            elif c == "Số lượng":
                tree_chitiet.column(c, width=60, anchor="center")
            else:  # Đơn giá nhập
                tree_chitiet.column(c, width=100, anchor="e")

        # 1. Thêm khung hiển thị Mã PN trên cùng
        frame_mapn = tk.Frame(right, bg=MAU_NEN_KHUNG)
        frame_mapn.pack(fill="x", padx=6, pady=(15, 10))
        tk.Label(
            frame_mapn,
            text="Mã PN:",
            font=FONT_TIEU_DE_NHO,
            bg=MAU_NEN_KHUNG,
            fg=MAU_CHU_CHINH,
        ).pack(side="left", padx=5)
        tk.Label(
            frame_mapn,
            textvariable=MaPN,
            font=("Segoe UI", 14, "bold"),
            bg=MAU_NEN_KHUNG,
            fg=MAU_NHAN,
        ).pack(side="left", padx=5)

        tk.Label(
            right,
            text="CHI TIẾT PHIẾU NHẬP",
            font=FONT_TIEU_DE_NHO,
            bg=MAU_NEN_KHUNG,
            fg=MAU_NHAN,
        ).pack(anchor="w", padx=6, pady=(10, 6))

        # 2. Tạo khung hiển thị Tổng tiền
        frame_tong_tien = tk.Frame(right, bg=MAU_NEN_KHUNG, pady=10)

        tk.Label(
            frame_tong_tien,
            text="TỔNG GIÁ TRỊ NHẬP:",
            font=("Segoe UI", 14, "bold"),
            bg=MAU_NEN_KHUNG,
            fg=MAU_CHU_CHINH,
        ).pack(side="left", padx=5)

        tk.Label(
            frame_tong_tien,
            textvariable=TongGiaTriNhap,
            font=("Segoe UI", 16, "bold"),
            bg=MAU_NEN_KHUNG,
            fg=MAU_NUT_THOAT,
        ).pack(side="right", padx=5)

        # Pack Treeview ở giữa, fill cả khung.
        tree_chitiet.pack(fill="both", expand=True, padx=6, pady=6)

        # Pack khung tổng tiền ở cuối cùng.
        frame_tong_tien.pack(fill="x", padx=6, pady=(10, 6), side="bottom")

    # ------------------ TRANG: QUẢN LÝ PHIẾU NHẬP ------------------
    def build_quan_ly_phieu_nhap(khung):
        MaPN = tk.StringVar()

        # BỔ SUNG: Hàm load dữ liệu Phiếu Nhập
        def load_data_pn(all_data=False):
            for item in tree.get_children():
                tree.delete(item)

            conn = connect()
            if not conn:
                return

            ma_pn = MaPN.get().strip()
            cursor = conn.cursor()

            # Query lấy Phiếu Nhập và tên Nhà Cung Cấp
            sql = """
            SELECT PN.MaPN, PN.MaNCC, NCC.TenNCC, PN.NgayNhap, PN.TongGiaTriNhap 
            FROM PHIEUNHAP PN
            JOIN NHACUNGCAP NCC ON PN.MaNCC = NCC.MaNCC
            """
            params = []

            if ma_pn and not all_data:
                sql += " WHERE PN.MaPN LIKE ?"
                params.append(f"%{ma_pn}%")

            sql += " ORDER BY PN.NgayNhap DESC"

            try:
                cursor.execute(sql, params)
                rows = cursor.fetchall()
                for row in rows:
                    tong_gt_format = format_currency(row[3])
                    # Định dạng ngày nếu là object
                    ngay_nhap_format = row[3].strftime("%Y-%m-%d") if row[3] else "N/A"
                    tree.insert("", tk.END, values=(row[0], row[1], row[2], ngay_nhap_format, tong_gt_format))

                if not rows:
                    messagebox.showinfo("Thông báo", "Không tìm thấy phiếu nhập nào.")

            except Exception as e:
                messagebox.showerror("Lỗi SQL", f"Lỗi truy vấn phiếu nhập: {e}")
            finally:
                conn.close()

        hdr = tk.Frame(khung, bg=MAU_NEN_CHINH)
        hdr.pack(fill="x", pady=8, padx=10)
        tk.Label(
            hdr,
            text="QUẢN LÝ PHIẾU NHẬP",
            font=FONT_TIEU_DE_LON,
            bg=MAU_NEN_CHINH,
            fg=MAU_NHAN,
        ).pack(anchor="w")

        # Khung trên: tìm kiếm/nhập hóa đơn
        khung_top = tk.Frame(khung, bg=MAU_NEN_KHUNG)
        khung_top.pack(fill="x", padx=10, pady=8)

        tk.Label(
            khung_top, text="Mã PN:", bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH
        ).grid(row=0, column=0, padx=(15, 8), pady=8, sticky="w")
        tk.Entry(khung_top, textvariable=MaPN, bg=MAU_NEN_NHAP, fg=MAU_CHU_CHINH, bd=0).grid(
            row=0, column=1, padx=8, pady=8
        )

        # BỔ SUNG: Gán command cho nút Tìm Phiếu Nhập
        tk.Button(
            khung_top,
            text="Tìm Phiếu Nhập",
            font=FONT_NUT,
            bg=MAU_NUT_NEN,
            fg=MAU_CHU_CHINH,
            bd=0,
            activebackground=MAU_NUT_HOVER,
            command=lambda: load_data_pn(all_data=False),
        ).grid(row=0, column=2, padx=8)

        # BỔ SUNG: Thêm nút Hiển thị tất cả
        tk.Button(
            khung_top,
            text="Hiển thị tất cả",
            font=FONT_NUT,
            bg=MAU_NUT_NEN,
            fg=MAU_CHU_CHINH,
            bd=0,
            activebackground=MAU_NUT_HOVER,
            command=lambda: load_data_pn(all_data=True),
        ).grid(row=0, column=3, padx=8)

        # Khung danh sách Phiếu Nhập
        tk.Label(
            khung,
            text="DANH SÁCH PHIẾU NHẬP",
            font=FONT_TIEU_DE_NHO,
            bg=MAU_NEN_CHINH,
            fg=MAU_NHAN,
        ).pack(anchor="w", padx=12, pady=(15, 0))
        cols = ("MaPN", "Mã NCC", "Nhà cung cấp", "Ngày nhập", "Tổng giá trị")
        tree = ttk.Treeview(khung, columns=cols, show="headings", height=14)

        for c in cols:
            tree.heading(c, text=c)
            if c == "Tổng giá trị":
                tree.column(c, width=120, anchor="e")
            else:
                tree.column(c, width=140, anchor="center")

        tree.pack(fill="both", expand=True, padx=12, pady=8)

        # BỔ SUNG: Tự động load dữ liệu khi mở trang
        khung.after(100, lambda: load_data_pn(all_data=True))

    # ------------------ TRANG: KIỂM KÊ TỒN KHO ------------------
    def build_kiem_ke_ton_kho(khung):
        MaSP = tk.StringVar()
        TenSP = tk.StringVar()

        # BỎ CHỨC NĂNG: Hàm load dữ liệu Tồn Kho (Chỉ hiển thị dữ liệu mẫu)
        def load_data_ton_kho(all_data=False):
            for item in tree.get_children():
                tree.delete(item)

            # Dữ liệu mẫu
            data_mau = [
                ("SP001", "Laptop A", "Cái", 15, format_currency(18500000)),
                ("SP002", "Chuột không dây X", "Chiếc", 250, format_currency(120000)),
                ("SP003", "Bàn phím cơ Z", "Chiếc", 50, format_currency(850000)),
            ]

            for row in data_mau:
                tree.insert("", tk.END, values=row)

        hdr = tk.Frame(khung, bg=MAU_NEN_CHINH)
        hdr.pack(fill="x", pady=8, padx=10)
        tk.Label(
            hdr,
            text="KIỂM KÊ TỒN KHO",
            font=FONT_TIEU_DE_LON,
            bg=MAU_NEN_CHINH,
            fg=MAU_NHAN,
        ).pack(anchor="w")

        # Khung tìm kiếm tồn kho
        khung_top = tk.Frame(khung, bg=MAU_NEN_KHUNG)
        khung_top.pack(fill="x", padx=10, pady=8)
        khung_top.columnconfigure(1, weight=1)
        khung_top.columnconfigure(3, weight=1)

        tk.Label(
            khung_top,
            text="Mã SP:",
            bg=MAU_NEN_KHUNG,
            fg=MAU_CHU_CHINH,
            font=FONT_NHAN,
        ).grid(row=0, column=0, padx=(15, 8), pady=8, sticky="w")
        tk.Entry(
            khung_top,
            textvariable=MaSP,
            bg=MAU_NEN_NHAP,
            fg=MAU_CHU_CHINH,
            bd=0,
            width=20,
            relief="flat",
        ).grid(row=0, column=1, padx=8, pady=8, sticky="ew")

        tk.Label(
            khung_top,
            text="Tên SP:",
            bg=MAU_NEN_KHUNG,
            fg=MAU_CHU_CHINH,
            font=FONT_NHAN,
        ).grid(row=0, column=2, padx=(15, 8), pady=8, sticky="w")
        tk.Entry(
            khung_top,
            textvariable=TenSP,
            bg=MAU_NEN_NHAP,
            fg=MAU_CHU_CHINH,
            bd=0,
            width=30,
            relief="flat",
        ).grid(row=0, column=3, padx=8, pady=8, sticky="ew")

        # Gán command cho nút Tìm kiếm
        tk.Button(
            khung_top,
            text="Tìm kiếm",
            font=FONT_NUT,
            bg=MAU_NUT_NEN,
            fg=MAU_CHU_CHINH,
            bd=0,
            activebackground=MAU_NUT_HOVER,
            command=lambda: load_data_ton_kho(all_data=False),
        ).grid(row=0, column=4, padx=(20, 15), sticky="e")

        # Thêm nút Hiển thị tất cả
        tk.Button(
            khung_top,
            text="Hiển thị tất cả",
            font=FONT_NUT,
            bg=MAU_NUT_NEN,
            fg=MAU_CHU_CHINH,
            bd=0,	
            activebackground=MAU_NUT_HOVER,
            command=lambda: load_data_ton_kho(all_data=True),
        ).grid(row=0, column=5, padx=(5, 15), sticky="e")

        # Danh sách Tồn kho
        tk.Label(
            khung,
            text="KẾT QUẢ TỒN KHO",
            font=FONT_TIEU_DE_NHO,
            bg=MAU_NEN_CHINH,
            fg=MAU_NHAN,
        ).pack(anchor="w", padx=12, pady=(15, 0))
        cols = ("Mã SP", "Tên SP", "Đơn vị tính", "Tồn kho", "Giá vốn (Đơn)")
        tree = ttk.Treeview(khung, columns=cols, show="headings", height=12)

        for c in cols:
            tree.heading(c, text=c)
            if c == "Tên SP":
                tree.column(c, width=220, anchor="w")
            elif c == "Tồn kho":
                tree.column(c, width=100, anchor="center")
            elif c == "Giá vốn (Đơn)":
                tree.column(c, width=120, anchor="e")
            else:
                tree.column(c, width=100, anchor="center")

        tree.pack(fill="both", expand=True, padx=12, pady=8)

        # BỎ CHỨC NĂNG: Tự động load dữ liệu khi mở trang, thay bằng gọi load dữ liệu mẫu.
        khung.after(100, lambda: load_data_ton_kho(all_data=True))


    # Gọi build cho từng trang
    build_lap_phieu_nhap(page_nhap)
    build_quan_ly_phieu_nhap(page_qlpn)
    build_kiem_ke_ton_kho(page_tonkho)

    # Hiển thị trang mặc định
    dat_trang_thai_hoat_dong(default_page)
    xu_ly_nhan_menu(default_page)

    # Trả về đối tượng cửa sổ (nếu cần)
    return cua_so_con
# ...existing code...