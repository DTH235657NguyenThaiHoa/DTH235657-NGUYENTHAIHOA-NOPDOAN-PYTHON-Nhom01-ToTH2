import tkinter as tk
from tkinter import ttk, messagebox
import os
import pyodbc
from datetime import date # Import để làm việc với ngày tháng
def connect():
    try:
        # Thay thế các giá trị kết nối bằng thông tin SQL Server của bạn
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=DESKTOP-DR4Q3K4;'  
            'DATABASE=QuanLyBanHang;'
            'Trusted_Connection=yes;'
        )
        return conn
    except Exception as e:
        print("Lỗi kết nối SQL Server: - GiaoDich.py:16", e)
        # Hiển thị lỗi nếu không kết nối được CSDL
        # messagebox.showerror("Lỗi Kết Nối", f"Không thể kết nối CSDL: {e}")
        return None

# ========== HẰNG SỐ MÀU SẮC ĐỒNG BỘ ========== (GIỮ NGUYÊN NHƯ TRANG CHỦ)
MAU_NEN_CHINH = "#0f1720"     # BG
MAU_NEN_MENU = "#132233"      # SIDEBAR_BG
MAU_NEN_KHUNG = "#172433"     # PANEL_BG
MAU_NEN_BANNER = "#052244"  # BANNER_TOP
MAU_NHAN = "#66AEE9"          # ACCENT
MAU_NUT_NEN = "#25455e"      # BTN_BG
MAU_NUT_HOVER = "#3a6f8e"    # BTN_ACTIVE
MAU_CHU_CHINH = "#eaf2fb"    # TEXT
MAU_NEN_NHAP = "#2b3d47"
MAU_NUT_THOAT = "#F85B50"

FONT_TIEU_DE = ("Segoe UI", 12, "bold")
FONT_PHU = ("Segoe UI", 9)
FONT_ICON = ("Segoe UI Emoji", 24)

# ========= Hàm tiện ích =========
def canh_giua_cua_so(win, w=1000, h=680):
    win.update_idletasks()
    ws = win.winfo_screenwidth()
    hs = win.winfo_screenheight()
    x = (ws // 2) - (w // 2)
    y = (hs // 2) - (h // 2)
    win.geometry(f'{w}x{h}+{x}+{y}')

# ========== Hàm chính để mở form Giao Dịch ==========
def MoFormGiaoDich(parent, default_page="TaoGiaoDich"):
    cua_so_con = tk.Toplevel(parent)
    cua_so_con.title("Giao dịch - Quản lý bán hàng")
    cua_so_con.config(bg=MAU_NEN_CHINH)
    canh_giua_cua_so(cua_so_con, 1000, 680)
    cua_so_con.resizable(False, False)

    # ========== Styles ==========
    style = ttk.Style()
    try:
        style.theme_use("clam")
    except Exception:
        pass

    style.configure("Header.TLabel", font=("Segoe UI", 18, "bold"),
                    foreground=MAU_CHU_CHINH, background=MAU_NEN_BANNER)
    style.configure("CardText.TLabel", font=("Segoe UI", 10),
                    foreground=MAU_CHU_CHINH, background=MAU_NEN_CHINH)

    # ========== LAYOUT: MenuBen & NoiDungChinh ==========
    menu_ben = tk.Frame(cua_so_con, bg=MAU_NEN_MENU, width=200)
    menu_ben.pack(side="left", fill="y")
    noi_dung_chinh = tk.Frame(cua_so_con, bg=MAU_NEN_CHINH)
    noi_dung_chinh.pack(side="left", fill="both", expand=True)

    # ===== MenuBen content (Icon & TenUngDung) =====
    icon_ung_dung = tk.Label(menu_ben, text="🛒", bg=MAU_NEN_MENU, fg=MAU_NHAN, font=("Segoe UI", 25))
    icon_ung_dung.pack(pady=(18,6))
    ten_ung_dung = tk.Label(menu_ben, text="QUẢN LÝ\nBÁN HÀNG\n", bg=MAU_NEN_MENU, fg=MAU_CHU_CHINH, font=("Segoe UI", 12, "bold"), justify="center")
    ten_ung_dung.pack(pady=(0,18))
    tieu_de_menu = tk.Label(menu_ben, text="Chức năng", bg=MAU_NEN_MENU, fg="#9fb8c9", font=("Segoe UI", 9, "bold"))
    tieu_de_menu.pack(anchor="w", padx=20, pady=(6,2))

    # ====== TẠO CÁC KHUNG NỘI DUNG (PAGE FRAMES) ======
    page_tao = tk.Frame(noi_dung_chinh, bg=MAU_NEN_CHINH)
    page_hoadon = tk.Frame(noi_dung_chinh, bg=MAU_NEN_CHINH)
    page_km = tk.Frame(noi_dung_chinh, bg=MAU_NEN_CHINH)

    for fr in (page_tao, page_hoadon, page_km):
        fr.place(relx=0, rely=0, relwidth=1, relheight=1)

    # ===== Sidebar buttons logic =====
    nut_menu = {}

    def dat_trang_thai_hoat_dong(nut_key):
        for k, nut in nut_menu.items():
            nut.config(bg=MAU_NEN_MENU, fg=MAU_CHU_CHINH)
        if nut_key in nut_menu:
            nut_menu[nut_key].config(bg=MAU_NUT_NEN, fg="white")

    def hien_thi_trang(trang):
        trang.tkraise()
        # Cập nhật dữ liệu khi chuyển trang
        if trang == page_hoadon:
            hien_thi_tat_ca_hoadon()
        elif trang == page_km:
            hien_thi_tat_ca_km()

    def xu_ly_nhan_menu(key):
        dat_trang_thai_hoat_dong(key)
        if key == "TaoGiaoDich":
            hien_thi_trang(page_tao)
        elif key == "HoaDon":
            hien_thi_trang(page_hoadon)
        elif key == "KhuyenMai":
            hien_thi_trang(page_km)

    danh_muc_menu = [
        ("TaoGiaoDich", "📝 Tạo Giao Dịch Mới"),
        ("HoaDon", "🧾 Hoá đơn"),
        ("KhuyenMai", "🏷️ Khuyến mãi"),
    ]

    for k, nhan in danh_muc_menu:
        nut = tk.Button(menu_ben, text=nhan, font=("Segoe UI", 11), bg=MAU_NEN_MENU, fg=MAU_CHU_CHINH,
                        activebackground=MAU_NUT_HOVER, activeforeground="white", bd=0,
                        command=lambda key=k: xu_ly_nhan_menu(key), anchor="w")
        nut.pack(fill="x", padx=20, pady=6)
        nut_menu[k] = nut

    tk.Frame(menu_ben, bg=MAU_NEN_MENU).pack(fill="both", expand=True)  # spacer
    tk.Button(menu_ben, text="Đóng", font=("Segoe UI", 11, "bold"), bg=MAU_NUT_THOAT, fg="white",
              bd=0, command=cua_so_con.destroy).pack(fill="x", padx=20, pady=(0, 18))

    # ========== Xây dựng từng trang nội dung ==========
    FONT_TIEU_DE_LON = ("Segoe UI", 16, "bold")
    FONT_NHAN = ("Segoe UI", 10)
    FONT_NUT = ("Segoe UI", 10, "bold")
    FONT_TIEU_DE_NHO = ("Segoe UI", 12, "bold")

    # --- KHAI BÁO BIẾN CHO CÁC CHỨC NĂNG (ĐỂ DỄ DÀNG TRUY CẬP TRONG CÁC HÀM XỬ LÝ) ---
    tree_hoadon = None
    tree_khuyenmai = None
    
    # ------------------ TRANG: TẠO GIAO DỊCH MỚI ------------------
    def build_tao_gd(khung):
        MaHD = tk.StringVar()
        KhachHang = tk.StringVar()
        NhanVien = tk.StringVar()
        NgayLap = tk.StringVar(value=date.today().strftime("%Y-%m-%d"))  # Ngày mặc định là hôm nay
        TongTien = tk.StringVar(value="0.00 VNĐ")

        # List tạm để lưu chi tiết giao dịch: (TenSP, SoLuong, DonGia)
        chi_tiet_gd_list = []

        # Helper: định dạng tiền
        def format_currency(value, suffix=" VNĐ"):
            try:
                # value có thể là float hoặc int
                v = float(value)
                # Hiển thị 2 chữ số thập phân, phân cách hàng nghìn bằng dấu phẩy
                return f"{v:,.2f}{suffix}"
            except Exception:
                return f"{value}{suffix}"

        # Tiêu đề
        hdr = tk.Frame(khung, bg=MAU_NEN_CHINH)
        hdr.pack(fill="x", pady=15, padx=20)
        tk.Label(hdr, text="TẠO GIAO DỊCH MỚI", font=FONT_TIEU_DE_LON, bg=MAU_NEN_CHINH, fg=MAU_NHAN).pack(anchor="w")

        # Khung nhập liệu (trái) và chi tiết giao dịch (phải)
        khung_chinh = tk.Frame(khung, bg=MAU_NEN_CHINH)
        khung_chinh.pack(fill="both", expand=True, padx=10, pady=10)

        # Khung LEFT (Đã tăng kích thước)
        left = tk.Frame(khung_chinh, bg=MAU_NEN_KHUNG, width=350)
        left.pack(side="left", fill="y", padx=(10, 5), pady=5)
        left.pack_propagate(False)

        right = tk.Frame(khung_chinh, bg=MAU_NEN_KHUNG)
        right.pack(side="left", fill="both", expand=True, padx=(5, 10), pady=5)

        # --- Nội dung left: form đơn giản ---
        def tao_nhan(k, text, r, c):
            tk.Label(k, text=text, font=FONT_NHAN, bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH).grid(row=r, column=c, sticky='w',
                                                                                                padx=6, pady=6)

        def tao_o(k, var, r, c):
            tk.Entry(k, textvariable=var, width=25, font=FONT_NHAN,
                    bg=MAU_NEN_NHAP, fg=MAU_CHU_CHINH, bd=0,
                    insertbackground=MAU_CHU_CHINH, relief="flat").grid(row=r, column=c, padx=6, pady=6)

        # Thêm Mã HD vào form (để nhập chi tiết theo HD)
        tao_nhan(left, "Mã HĐ:", 0, 0)
        tao_o(left, MaHD, 0, 1)

        tao_nhan(left, "Khách hàng:", 2, 0)
        tao_o(left, KhachHang, 2, 1)

        tao_nhan(left, "Nhân viên:", 3, 0)
        tao_o(left, NhanVien, 3, 1)

        tao_nhan(left, "Ngày GD:", 4, 0)
        tao_o(left, NgayLap, 4, 1)

        # Khung nhập chi tiết SP
        frame_chi_tiet = tk.Frame(left, bg=MAU_NEN_KHUNG, pady=10)
        frame_chi_tiet.grid(row=6, column=0, columnspan=2, pady=(15, 5))

        # Biến tạm cho chi tiết sản phẩm
        TenSP = tk.StringVar()
        SoLuong = tk.StringVar()
        DonGia = tk.StringVar()

        tk.Label(frame_chi_tiet, text="Thêm Sản Phẩm", font=FONT_TIEU_DE_NHO, bg=MAU_NEN_KHUNG, fg=MAU_NHAN).grid(
            row=0, column=0, columnspan=4, sticky="w", padx=6, pady=(0, 5))

        tk.Label(frame_chi_tiet, text="Tên SP:", font=FONT_NHAN, bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH).grid(row=1, column=0,
                                                                                                        sticky='w', padx=6,
                                                                                                        pady=2)
        tk.Entry(frame_chi_tiet, textvariable=TenSP, width=20, font=FONT_NHAN, bg=MAU_NEN_NHAP, fg=MAU_CHU_CHINH, bd=0,
                relief="flat").grid(row=1, column=1, columnspan=3, padx=6, pady=2, sticky='ew')

        tk.Label(frame_chi_tiet, text="SL:", font=FONT_NHAN, bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH).grid(row=2, column=0,
                                                                                                        sticky='w', padx=6,
                                                                                                        pady=2)
        tk.Entry(frame_chi_tiet, textvariable=SoLuong, width=8, font=FONT_NHAN, bg=MAU_NEN_NHAP, fg=MAU_CHU_CHINH, bd=0,
                relief="flat").grid(row=2, column=1, padx=6, pady=2, sticky='w')

        tk.Label(frame_chi_tiet, text="Đơn giá:", font=FONT_NHAN, bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH).grid(row=2, column=2,
                                                                                                        sticky='w', padx=6,
                                                                                                        pady=2)
        tk.Entry(frame_chi_tiet, textvariable=DonGia, width=12, font=FONT_NHAN, bg=MAU_NEN_NHAP, fg=MAU_CHU_CHINH, bd=0,
                relief="flat").grid(row=2, column=3, padx=6, pady=2, sticky='w')

        # --- Cấu hình Treeview (trước khi định nghĩa hàm them_gd) ---
        cols = ("Tên SP", "Số lượng", "Đơn giá")
        tree_chitiet = ttk.Treeview(right, columns=cols, show="headings", height=12)

        st = ttk.Style()
        try:
            st.theme_use("clam")
        except Exception:
            pass
        st.configure("Treeview", background=MAU_NEN_KHUNG, foreground=MAU_CHU_CHINH, fieldbackground=MAU_NEN_KHUNG, rowheight=24)
        st.map("Treeview", background=[("selected", MAU_NUT_NEN)])
        st.configure("Treeview.Heading", background=MAU_NUT_NEN, foreground=MAU_CHU_CHINH, font=('Segoe UI', 10, 'bold'))

        for c in cols:
            tree_chitiet.heading(c, text=c)
            if c == "Tên SP":
                tree_chitiet.column(c, width=180, anchor="w")
            elif c == "Số lượng":
                tree_chitiet.column(c, width=70, anchor="center")
            else:  # Đơn giá
                tree_chitiet.column(c, width=120, anchor="e")

        # BỔ SUNG: Hàm cập nhật Treeview chi tiết và tổng tiền
        def cap_nhat_chi_tiet_gd():
            # Xóa dữ liệu cũ
            for item in tree_chitiet.get_children():
                tree_chitiet.delete(item)

            tong = 0.0
            for sp in chi_tiet_gd_list:
                ten_sp, sl, dg = sp
                thanh_tien = sl * dg
                tong += thanh_tien
                # hiển thị DonGia hoặc Thành tiền tùy bạn; ở đây hiển thị DonGia
                tree_chitiet.insert("", tk.END, values=(ten_sp, sl, format_currency(dg)))

            TongTien.set(format_currency(tong))

        # BỔ SUNG: Hàm xử lý nút "Thêm sản phẩm"
        def them_san_pham_vao_gd():
            ten_sp = TenSP.get().strip()
            sl_str = SoLuong.get().strip()
            dg_str = DonGia.get().strip()

            if not ten_sp or not sl_str or not dg_str:
                messagebox.showwarning("Lỗi nhập liệu", "Vui lòng nhập đầy đủ Tên SP, Số lượng và Đơn giá.")
                return

            try:
                sl = int(sl_str)
                # Xử lý định dạng tiền tệ nếu có dấu phân cách
                dg = float(dg_str.replace(".", "").replace(",", "")) if isinstance(dg_str, str) else float(dg_str)
                if sl <= 0 or dg <= 0:
                    raise ValueError
            except ValueError:
                messagebox.showwarning("Lỗi định dạng", "Số lượng và Đơn giá phải là số dương hợp lệ.")
                return

            # Thêm vào list tạm thời
            chi_tiet_gd_list.append((ten_sp, sl, dg))

            # Cập nhật UI
            cap_nhat_chi_tiet_gd()

            # Xóa trường nhập liệu SP
            TenSP.set("")
            SoLuong.set("")
            DonGia.set("")

        # BỔ SUNG: Hàm xử lý nút "Xoá sản phẩm"
        def xoa_san_pham_khoi_gd():
            selected_item = tree_chitiet.selection()
            if not selected_item:
                messagebox.showwarning("Cảnh báo", "Vui lòng chọn sản phẩm cần xóa.")
                return

            # Lấy index của item được chọn trong list tạm
            item_index = tree_chitiet.index(selected_item[0])

            if 0 <= item_index < len(chi_tiet_gd_list):
                chi_tiet_gd_list.pop(item_index)

            # Cập nhật UI
            cap_nhat_chi_tiet_gd()

        # BỔ SUNG: Hàm xử lý nút "Huỷ Giao Dịch" (Reset Form)
        def huy_giao_dich():
            MaHD.set("")
            KhachHang.set("")
            NhanVien.set("")
            NgayLap.set(date.today().strftime("%Y-%m-%d"))
            TongTien.set(format_currency(0.0))

            TenSP.set("")
            SoLuong.set("")
            DonGia.set("")

            chi_tiet_gd_list.clear()
            cap_nhat_chi_tiet_gd()

        # BỔ SUNG: Hàm xử lý nút "Lưu Hoá Đơn" (Ghi vào CSDL)
        def luu_giao_dich():
            ma_hd = MaHD.get().strip()
            ma_kh = KhachHang.get().strip()
            ma_nv = NhanVien.get().strip()
            ngay = NgayLap.get().strip()

            if not all([ma_hd, ma_kh, ma_nv, ngay]):
                messagebox.showwarning("Lỗi nhập liệu", "Vui lòng nhập đầy đủ Mã HĐ, Mã KH, Mã NV và Ngày giao dịch.")
                return

            if not chi_tiet_gd_list:
                messagebox.showwarning("Cảnh báo", "Vui lòng thêm ít nhất một sản phẩm vào hoá đơn.")
                return

            conn = connect()
            if not conn:
                return
            cursor = conn.cursor()

            try:
                # 1. Lấy MaSP từ TenSP và kiểm tra sự tồn tại của SP
                san_pham_map = {}
                for ten_sp, _, _ in chi_tiet_gd_list:
                    cursor.execute("SELECT MaSP, TonKho FROM SANPHAM WHERE TenSP = ?", ten_sp)
                    result = cursor.fetchone()
                    if result:
                        san_pham_map[ten_sp] = {"MaSP": result[0], "TonKho": result[1] if len(result) > 1 else None}
                    else:
                        messagebox.showerror("Lỗi SP", f"Sản phẩm '{ten_sp}' không tìm thấy. Vui lòng thêm sản phẩm vào danh mục trước.")
                        conn.close()
                        return

                # 2. Tính tổng tiền và chuẩn bị dữ liệu CHITIETHOADON
                chi_tiet_data = []
                tong = 0.0
                for ten_sp, sl, dg in chi_tiet_gd_list:
                    ma_sp = san_pham_map[ten_sp]["MaSP"]
                    thanh_tien = sl * dg
                    tong += thanh_tien
                    chi_tiet_data.append((ma_hd, ma_sp, sl, dg))

                    # Kiểm tra tồn kho (nếu muốn cảnh báo khi tồn kho không đủ)
                    ton = san_pham_map[ten_sp].get("TonKho")
                    if ton is not None and ton < sl:
                        if not messagebox.askyesno("Cảnh báo tồn kho", f"Tồn kho sản phẩm '{ten_sp}' chỉ còn {ton}. Vẫn tiếp tục?"):
                            conn.close()
                            return

                # 3. Insert HOADON
                sql_hd = "INSERT INTO HOADON (MaHD, MaKH, MaNV, NgayLap, TongTien) VALUES (?, ?, ?, ?, ?)"
                cursor.execute(sql_hd, (ma_hd, ma_kh, ma_nv, ngay, tong))

                # 4. Insert CHITIETHOADON
                sql_ct = "INSERT INTO CHITIETHOADON (MaHD, MaSP, SoLuong, DonGia) VALUES (?, ?, ?, ?)"
                cursor.executemany(sql_ct, chi_tiet_data)

                # 5. Update Tồn Kho (TonKho) trong SANPHAM: trừ đi số lượng bán
                for ten_sp, sl, dg in chi_tiet_gd_list:
                    ma_sp = san_pham_map[ten_sp]["MaSP"]
                    sql_update_sp = "UPDATE SANPHAM SET TonKho = TonKho - ? WHERE MaSP = ?"
                    cursor.execute(sql_update_sp, (sl, ma_sp))

                conn.commit()
                messagebox.showinfo("Thành công", f"Đã lưu Hóa Đơn {ma_hd} thành công.")
                huy_giao_dich()  # Reset form

            except pyodbc.IntegrityError as e:
                messagebox.showerror("Lỗi CSDL", f"Lỗi trùng lặp Mã HĐ hoặc khóa ngoại không tồn tại: {e}")
                conn.rollback()
            except Exception as e:
                messagebox.showerror("Lỗi", f"Lỗi khi lưu hoá đơn: {e}")
                conn.rollback()
            finally:
                conn.close()

        # Buttons thao tác GD (gán command)
        tk.Button(frame_chi_tiet, text="Thêm sản phẩm", bg=MAU_NUT_NEN, fg=MAU_CHU_CHINH, font=FONT_NUT, width=15,
                activebackground=MAU_NUT_HOVER, activeforeground="white", bd=0, command=them_san_pham_vao_gd).grid(
            row=4, column=0, columnspan=2, pady=10, padx=6, sticky='w')
        tk.Button(frame_chi_tiet, text="Xoá sản phẩm", bg=MAU_NUT_NEN, fg=MAU_CHU_CHINH, font=FONT_NUT, width=15,
                activebackground=MAU_NUT_HOVER, activeforeground="white", bd=0, command=xoa_san_pham_khoi_gd).grid(
            row=4, column=2, columnspan=2, pady=10, padx=6, sticky='w')

        # Buttons thao tác chính (Lưu/Huỷ)
        frame_btns_chinh = tk.Frame(left, bg=MAU_NEN_KHUNG)
        frame_btns_chinh.grid(row=8, column=0, columnspan=2, pady=(15, 10))

        tk.Button(frame_btns_chinh, text="Lưu Hoá Đơn", bg=MAU_NUT_NEN, fg=MAU_CHU_CHINH, font=FONT_NUT, width=12,
                activebackground=MAU_NUT_HOVER, activeforeground="white", bd=0, command=luu_giao_dich).pack(side="left",
                                                                                                            padx=6)

        tk.Button(frame_btns_chinh, text="Huỷ Giao Dịch", bg=MAU_NUT_THOAT, fg="white", font=FONT_NUT, width=12,
                activebackground="#a83c34", activeforeground="white", bd=0, command=huy_giao_dich).pack(side="left",
                                                                                                        padx=6)

        # --- Nội dung right: Treeview chi tiết sản phẩm ---
        # 1. Thêm khung hiển thị Mã HD trên cùng
        frame_mahd = tk.Frame(right, bg=MAU_NEN_KHUNG)
        frame_mahd.pack(fill="x", padx=6, pady=(15, 10))
        tk.Label(frame_mahd, text="Mã HĐ:", font=FONT_TIEU_DE_NHO, bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH).pack(side="left",
                                                                                                            padx=5)
        tk.Label(frame_mahd, textvariable=MaHD, font=("Segoe UI", 14, "bold"), bg=MAU_NEN_KHUNG, fg=MAU_NHAN).pack(
            side="left", padx=5)

        tk.Label(right, text="CHI TIẾT HOÁ ĐƠN", font=FONT_TIEU_DE_NHO, bg=MAU_NEN_KHUNG, fg=MAU_NHAN).pack(anchor="w",
                                                                                                            padx=6, pady=(
                10, 6))

        # 2. Tạo khung hiển thị Tổng tiền (Được đặt ngay sau Treeview)
        frame_tong_tien = tk.Frame(right, bg=MAU_NEN_KHUNG, pady=10)
        frame_tong_tien.pack(fill="x", padx=6, pady=(10, 6), side="bottom")

        tk.Label(frame_tong_tien, text="THÀNH TIỀN:",
                font=("Segoe UI", 14, "bold"), bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH).pack(side="left", padx=5)

        tk.Label(frame_tong_tien, textvariable=TongTien,
                font=("Segoe UI", 16, "bold"), bg=MAU_NEN_KHUNG, fg=MAU_NUT_THOAT).pack(side="right", padx=5)

        # 3. Treeview chi tiết sản phẩm (đã định nghĩa ở trên)
        tree_chitiet.pack(fill="both", expand=True, padx=6, pady=6)

        # Khởi tạo (nếu muốn hiển thị dữ liệu từ list lúc mở form)
        cap_nhat_chi_tiet_gd()

        
    # ------------------ TRANG: HOÁ ĐƠN ------------------
    def hien_thi_tat_ca_hoadon():
        """Hiển thị tất cả hóa đơn từ CSDL lên Treeview."""
        conn = connect()
        if conn:
            cursor = conn.cursor()
            try:
                query = """
                    SELECT
                        HD.MaHD, NV.TenNV, KH.TenKH, HD.NgayLap, HD.TongTien
                    FROM HOADON HD
                    JOIN NHANVIEN NV ON HD.MaNV = NV.MaNV
                    JOIN KHACHHANG KH ON HD.MaKH = KH.MaKH
                    ORDER BY HD.NgayLap DESC
                """
                cursor.execute(query)
                rows = cursor.fetchall()
                
                # Xóa dữ liệu cũ
                for item in tree_hoadon.get_children():
                    tree_hoadon.delete(item)
                    
                # Chèn dữ liệu mới
                for row in rows:
                    mahd = row[0]
                    ten_nv = row[1]
                    ten_kh = row[2]
                    ngay_lap = row[3].strftime("%Y-%m-%d") if row[3] else ""
                    # Định dạng Tổng tiền
                    tong_tien = f"{row[4]:,.0f} VNĐ" if row[4] is not None else "0 VNĐ"
                    
                    tree_hoadon.insert("", "end", values=(mahd, ten_nv, ten_kh, ngay_lap, tong_tien))

            except pyodbc.ProgrammingError as pe:
                messagebox.showerror("Lỗi CSDL", f"Lỗi cú pháp SQL: {pe}")
            except Exception as e:
                messagebox.showerror("Lỗi", f"Lỗi khi tải dữ liệu Hóa đơn: {e}")
            finally:
                conn.close()
        else:
            messagebox.showerror("Lỗi", "Không thể kết nối CSDL để tải Hóa đơn.")

    def tim_kiem_hoadon(tree, search_term):
        conn = connect()
        if not conn: return

        # Xóa dữ liệu cũ
        for item in tree.get_children():
            tree.delete(item)

        try:
            cursor = conn.cursor()
            search_pattern = f'%{search_term.get().strip()}%'

            query = """
                SELECT
                    HD.MaHD, NV.TenNV, KH.TenKH, HD.NgayLap, HD.TongTien
                FROM HOADON HD
                JOIN NHANVIEN NV ON HD.MaNV = NV.MaNV
                JOIN KHACHHANG KH ON HD.MaKH = KH.MaKH
                WHERE HD.MaHD LIKE ? OR KH.TenKH LIKE ? OR NV.TenNV LIKE ?
                ORDER BY HD.NgayLap DESC
            """
            cursor.execute(query, search_pattern, search_pattern, search_pattern)
            rows = cursor.fetchall()

            for row in rows:
                mahd = row[0]
                ten_nv = row[1]
                ten_kh = row[2]
                ngay_lap = row[3].strftime("%Y-%m-%d") if row[3] else ""
                tong_tien = f"{row[4]:,.0f} VNĐ" if row[4] is not None else "0 VNĐ"
                tree.insert("", "end", values=(mahd, ten_nv, ten_kh, ngay_lap, tong_tien))

            if not rows:
                messagebox.showinfo("Thông báo", "Không tìm thấy Hóa đơn phù hợp.")

        except Exception as e:
            messagebox.showerror("Lỗi", f"Lỗi tìm kiếm Hóa đơn: {e}")
        finally:
            conn.close()
            
    def build_hoadon(khung):
        nonlocal tree_hoadon # Sử dụng biến toàn cục cho Treeview

        MaHD_TimKiem = tk.StringVar()
        
        hdr = tk.Frame(khung, bg=MAU_NEN_CHINH)
        hdr.pack(fill="x", pady=8, padx=10)
        tk.Label(hdr, text="HOÁ ĐƠN", font=FONT_TIEU_DE_LON, bg=MAU_NEN_CHINH, fg=MAU_NHAN).pack(anchor="w")

        # Khung trên: tìm kiếm/nhập hóa đơn
        khung_top = tk.Frame(khung, bg=MAU_NEN_KHUNG)
        khung_top.pack(fill="x", padx=10, pady=8)

        tk.Label(khung_top, text="Nhập Mã/Tên:", bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH).grid(row=0, column=2, padx=(10, 8), pady=8, sticky='w')
        tk.Entry(khung_top, textvariable=MaHD_TimKiem, bg=MAU_NEN_NHAP, fg=MAU_CHU_CHINH, bd=0).grid(row=0, column=3, padx=8, pady=8)

        tk.Button(khung_top, text="Tìm hoá đơn", bg=MAU_NUT_NEN, fg=MAU_CHU_CHINH,
                  command=lambda: tim_kiem_hoadon(tree_hoadon, MaHD_TimKiem)).grid(row=0, column=4, padx=8)

        # Khung danh sách hoá đơn
        tk.Label(khung, text="DANH SÁCH HOÁ ĐƠN", font=FONT_TIEU_DE_NHO, bg=MAU_NEN_CHINH, fg=MAU_NHAN).pack(anchor="w", padx=12)
        cols = ("MaHD", "Mã NV", "Khách hàng", "Ngày lập", "Tổng tiền")
        
        # Gán Treeview vào biến toàn cục
        tree_hoadon = ttk.Treeview(khung, columns=cols, show="headings", height=14)
        for c in cols:
            tree_hoadon.heading(c, text=c)
            if c == "Tổng tiền":
                 tree_hoadon.column(c, width=150, anchor="e")
            else:
                 tree_hoadon.column(c, width=140, anchor="center")
        tree_hoadon.pack(fill="both", expand=True, padx=12, pady=8)

        # style
        st = ttk.Style()
        try:
            st.theme_use("clam")
        except Exception:
            pass
        st.configure("Treeview", background=MAU_NEN_KHUNG, foreground=MAU_CHU_CHINH, fieldbackground=MAU_NEN_KHUNG, rowheight=24)
        st.map("Treeview", background=[("selected", MAU_NUT_NEN)])
        st.configure("Treeview.Heading", background=MAU_NUT_NEN, foreground=MAU_CHU_CHINH, font=('Segoe UI', 10, 'bold'))

        # Tải dữ liệu lần đầu
        hien_thi_tat_ca_hoadon()

    # ------------------ TRANG: KHUYẾN MÃI ------------------
    def hien_thi_tat_ca_km():
        conn = connect()
        if conn:
            cursor = conn.cursor()
            try:
                query = "SELECT MaKM, TenKM, GiaTri, NgayBatDau, NgayKetThuc FROM KHUYENMAI"
                cursor.execute(query)
                rows = cursor.fetchall()
                
                # Xóa dữ liệu cũ
                for item in tree_khuyenmai.get_children():
                    tree_khuyenmai.delete(item)
                    
                # Chèn dữ liệu mới
                for row in rows:
                    makm = row[0]
                    tenkm = row[1]
                    
                    # === ĐIỀU CHỈNH LỖI TẠI ĐÂY: Xử lý giá trị có ký tự '%' ===
                    if row[2] is not None:
                        # Chuyển đổi sang chuỗi, loại bỏ '%' và khoảng trắng (nếu có)
                        raw_value = str(row[2]).replace('%', '').strip()
                        try:
                            # Chuyển đổi thành float và định dạng lại chuỗi kết quả thêm '%'
                            giatri = f"{float(raw_value):.0f}%"
                        except ValueError:
                            # Nếu vẫn lỗi chuyển đổi (dữ liệu CSDL bị lỗi), dùng giá trị thô
                            giatri = str(row[2]) 
                    else:
                        giatri = "0%"
                    # =========================================================

                    ngay_bd = row[3].strftime("%Y-%m-%d") if row[3] else ""
                    ngay_kt = row[4].strftime("%Y-%m-%d") if row[4] else ""
                    
                    tree_khuyenmai.insert("", "end", values=(makm, tenkm, giatri, ngay_bd, ngay_kt))

            except pyodbc.ProgrammingError as pe:
                messagebox.showerror("Lỗi CSDL", f"Lỗi cú pháp SQL: {pe}")
            except Exception as e:
                # Hiển thị lỗi đã được báo cáo
                messagebox.showerror("Lỗi", f"Lỗi khi tải dữ liệu Khuyến mãi: {e}")
            finally:
                conn.close()
        else:
            messagebox.showerror("Lỗi", "Không thể kết nối CSDL để tải Khuyến mãi.")
            
    def them_khuyen_mai(MaKM_var, TenKM_var, GiaTri_var, BatDau_var, KetThuc_var):
        makm = MaKM_var.get().strip()
        tenkm = TenKM_var.get().strip()
        giatri_str = GiaTri_var.get().strip() # Đặt tên mới để tránh nhầm lẫn với giá trị float
        batdau = BatDau_var.get().strip()
        ketthuc = KetThuc_var.get().strip()

        if not all([makm, tenkm, giatri_str, batdau, ketthuc]):
            messagebox.showwarning("Cảnh báo", "Vui lòng điền đầy đủ thông tin Khuyến mãi.")
            return

        try:
            # Loại bỏ % nếu người dùng nhập và chuyển sang float để lưu CSDL
            giatri_clean = giatri_str.replace('%', '').strip()
            giatri = float(giatri_clean) 
            if not (0 <= giatri <= 100):
                 messagebox.showwarning("Cảnh báo", "Giá trị khuyến mãi phải nằm trong khoảng 0-100.")
                 return
        except ValueError:
            messagebox.showwarning("Cảnh báo", "Giá trị khuyến mãi phải là số hợp lệ.")
            return

        conn = connect()
        if conn:
            cursor = conn.cursor()
            try:
                # Kiểm tra trùng Mã KM
                cursor.execute("SELECT MaKM FROM KHUYENMAI WHERE MaKM = ?", makm)
                if cursor.fetchone():
                    messagebox.showwarning("Trùng mã", "Mã khuyến mãi đã tồn tại.")
                    return
                
                # === ĐIỀU CHỈNH LỖI TẠI ĐÂY: Thêm GiaTri vào cột INSERT và tham số thực thi ===
                query = "INSERT INTO KHUYENMAI (MaKM, TenKM, GiaTri, NgayBatDau, NgayKetThuc) VALUES (?, ?, ?, ?, ?)"
                cursor.execute(query, makm, tenkm, giatri, batdau, ketthuc)
                conn.commit()
                messagebox.showinfo("Thành công", "Thêm khuyến mãi mới thành công!")
                
                # Cập nhật lại Treeview
                hien_thi_tat_ca_km()
                
            except pyodbc.ProgrammingError as pe:
                messagebox.showerror("Lỗi CSDL", f"Lỗi cú pháp SQL: {pe}")
            except Exception as e:
                messagebox.showerror("Lỗi", f"Lỗi khi thêm Khuyến mãi: {e}")
            finally:
                conn.close()

    def build_khuyen_mai(khung):
        nonlocal tree_khuyenmai # Sử dụng biến toàn cục cho Treeview

        MaKM = tk.StringVar()
        TenKM = tk.StringVar()
        GiaTri = tk.StringVar()
        BatDau = tk.StringVar(value=date.today().strftime("%Y-%m-%d"))
        KetThuc = tk.StringVar(value=(date.today()).strftime("%Y-%m-%d")) # Mặc định là ngày hôm nay

        hdr = tk.Frame(khung, bg=MAU_NEN_CHINH)
        hdr.pack(fill="x", pady=8, padx=10)
        tk.Label(hdr, text="KHUYẾN MÃI", font=FONT_TIEU_DE_LON, bg=MAU_NEN_CHINH, fg=MAU_NHAN).pack(anchor="w")

        khung_form = tk.Frame(khung, bg=MAU_NEN_KHUNG)
        khung_form.pack(fill="x", padx=12, pady=8)

        def tao_label(h, txt, r, c):
            tk.Label(h, text=txt, bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH).grid(row=r, column=c, padx=6, pady=6, sticky='w')
        def tao_entry(h, var, w, r, c):
            tk.Entry(h, textvariable=var, width=w, bg=MAU_NEN_NHAP, fg=MAU_CHU_CHINH, bd=0).grid(row=r, column=c, padx=6, pady=6)

        tao_label(khung_form, "Mã KM:", 0, 0)
        tao_entry(khung_form, MaKM, 20, 0, 1)

        tao_label(khung_form, "Tên KM:", 1, 0)
        tao_entry(khung_form, TenKM, 30, 1, 1)
        tao_label(khung_form, "Giá trị (%):", 1, 2)
        tao_entry(khung_form, GiaTri, 20, 1, 3)

        tao_label(khung_form, "Bắt đầu (YYYY-MM-DD):", 2, 0)
        tao_entry(khung_form, BatDau, 20, 2, 1)
        tao_label(khung_form, "Kết thúc (YYYY-MM-DD):", 2, 2)
        tao_entry(khung_form, KetThuc, 20, 2, 3)

        # Buttons (Đã thêm command)
        
        # Thêm KM (đã gắn command)
        tk.Button(khung_form, text="Thêm KM",font=("Segoe UI", 9, "bold"), bg=MAU_NUT_NEN, fg=MAU_CHU_CHINH, relief="raised",
                  width=12, activebackground=MAU_NHAN, activeforeground=MAU_NEN_CHINH, 
                  command=lambda: them_khuyen_mai(MaKM, TenKM, GiaTri, BatDau, KetThuc)).grid(row=0, column=4, padx=50, pady=8)
        
        # Lưu (có thể dùng để sửa KM, tạm thời không gán logic Sửa)
        tk.Button(khung_form, text="Lưu/Sửa",font=("Segoe UI", 9, "bold"), bg=MAU_NUT_NEN, fg=MAU_CHU_CHINH, relief="raised",
                  width=12, activebackground=MAU_NHAN, activeforeground=MAU_NEN_CHINH).grid(row=1, column=4, padx=0, pady=8)

        # Danh sách KM
        tk.Label(khung, text="DANH SÁCH KHUYẾN MÃI", font=FONT_TIEU_DE_NHO, bg=MAU_NEN_CHINH, fg=MAU_NHAN).pack(anchor="w", padx=12)
        cols = ("Mã KM", "Tên KM", "Giá trị", "Bắt đầu", "Kết thúc")
        
        # Gán Treeview vào biến toàn cục
        tree_khuyenmai = ttk.Treeview(khung, columns=cols, show="headings", height=12)
        for c in cols:
            tree_khuyenmai.heading(c, text=c)
            tree_khuyenmai.column(c, width=140, anchor="center")
            
        tree_khuyenmai.pack(fill="both", expand=True, padx=12, pady=8)
        
        # Style cho Treeview (đảm bảo đồng bộ)
        st = ttk.Style()
        try:
            st.theme_use("clam")
        except Exception:
            pass
        st.configure("Treeview", background=MAU_NEN_KHUNG, foreground=MAU_CHU_CHINH, fieldbackground=MAU_NEN_KHUNG, rowheight=24)
        st.map("Treeview", background=[("selected", MAU_NUT_NEN)])
        st.configure("Treeview.Heading", background=MAU_NUT_NEN, foreground=MAU_CHU_CHINH, font=('Segoe UI', 10, 'bold'))

    # Gọi build cho từng trang
    build_tao_gd(page_tao)
    build_hoadon(page_hoadon)
    build_khuyen_mai(page_km)
    
    # Tải dữ liệu Khuyến mãi lần đầu tiên khi chuyển đến trang này
    if default_page == "KhuyenMai":
        hien_thi_tat_ca_km()

    # Hiển thị trang mặc định
    dat_trang_thai_hoat_dong(default_page)
    xu_ly_nhan_menu(default_page)

    # Trả về đối tượng cửa sổ (nếu cần)
    return cua_so_con