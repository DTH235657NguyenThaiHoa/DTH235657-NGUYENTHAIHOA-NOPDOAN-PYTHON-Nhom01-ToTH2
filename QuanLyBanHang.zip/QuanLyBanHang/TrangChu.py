import tkinter as tk
from tkinter import ttk
from QuanLy import MoFormQuanLy # Giữ nguyên tên file import, giả sử file kia tên là QuanLy.py
from GiaoDich import MoFormGiaoDich #mở giao dịch
from KhoHang import MoFormKhoHang  # mở kho hàng
from Login import MoFormLogin
import sys
import pyodbc

def connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=DESKTOP-DR4Q3K4;'
            'DATABASE=QuanLyBanHang;'
            'Trusted_Connection=yes;'
        )
        return conn
    except Exception as e:
        print("Lỗi kết nối SQL Server:", e)
        return None

# ========== HẰNG SỐ MÀU SẮC ĐỒNG BỘ ==========
MAU_NEN_CHINH = "#0f1720" 	    # BG
MAU_NEN_MENU = "#132233" 	# SIDEBAR_BG
MAU_NEN_KHUNG = "#172433" 	# PANEL_BG
MAU_NEN_BANNER = "#052244" 	# BANNER_TOP
MAU_NHAN = "#66AEE9" 	        # ACCENT
MAU_NUT_NEN = "#25455e" 	    # BTN_BG
MAU_NUT_HOVER = "#3a6f8e" 	# BTN_ACTIVE
MAU_CHU_CHINH = "#eaf2fb" 	# TEXT

# === HẰNG SỐ CARD (Đã điều chỉnh để khớp Dark Mode) ===
MAU_NEN_CARD = MAU_NEN_KHUNG 	    # CARD_BG
MAU_CARD_HOVER = "#25455e" 	    # CARD_HOVER
MAU_VIEN_CARD = "#2b3d47" 	    # CARD_BD
FONT_TIEU_DE = ("Segoe UI", 12, "bold") # TITLE_FONT
FONT_PHU = ("Segoe UI", 9) 	    # SUB_FONT
FONT_ICON = ("Segoe UI Emoji", 32) 	# ICON_FONT
# ==========================================================

cua_so_goc = tk.Tk()
cua_so_goc.title("Hệ thống quản lý bán hàng")
cua_so_goc.geometry(f"{1050}x{680}")
cua_so_goc.configure(bg=MAU_NEN_CHINH)
cua_so_goc.resizable(True, True)

# ========== Styles (Giữ nguyên) ==========
style = ttk.Style()
style.theme_use("clam")

style.configure("TLabel", background=MAU_NEN_CHINH, foreground=MAU_CHU_CHINH, font=("Segoe UI", 10))
style.configure("Header.TLabel", font=("Segoe UI", 20, "bold"), foreground="white", background=MAU_NEN_BANNER)
style.configure("CardTitle.TLabel", font=("Segoe UI", 11, "bold"), foreground=MAU_NHAN, background=MAU_NEN_KHUNG)
style.configure("CardText.TLabel", font=("Segoe UI", 10), foreground=MAU_CHU_CHINH, background=MAU_NEN_KHUNG)
style.configure("Sidebar.TButton", font=("Segoe UI", 11), background=MAU_NEN_MENU, foreground=MAU_CHU_CHINH, relief="flat")
style.map("Sidebar.TButton",
          background=[('active', MAU_NUT_HOVER)],
          foreground=[('active', 'white')])
style.configure("TButton", relief="flat", padding=6)
style.configure("Small.TButton", font=("Segoe UI", 9, "bold"))

# ========== LAYOUT: MenuBen & NoiDungChinh ==========
menu_ben = tk.Frame(cua_so_goc, bg=MAU_NEN_MENU, width=1000) 
menu_ben.pack(side="left", fill="both") 

# Khu vực chính
noi_dung_chinh = tk.Frame(cua_so_goc, bg=MAU_NEN_CHINH)
noi_dung_chinh.pack(side="left", fill="both", expand=True)

# ===== Nội dung MenuBen =====
icon_ung_dung = tk.Label(menu_ben, text="🛒", bg=MAU_NEN_MENU, fg=MAU_NHAN, font=("Segoe UI", 25))
icon_ung_dung.pack(pady=(18,6))

ten_ung_dung = tk.Label(menu_ben, text="QUẢN LÝ\nBÁN HÀNG\n", bg=MAU_NEN_MENU, fg=MAU_CHU_CHINH, font=("Segoe UI", 12, "bold"), justify="center")
ten_ung_dung.pack(pady=(0,18))

nhan_menu = tk.Label(menu_ben, text="Chức năng", bg=MAU_NEN_MENU, fg="#9fb8c9", font=("Segoe UI", 9, "bold"))
nhan_menu.pack(anchor="w", padx=30, pady=(6,2)) 

nut_menu = {}

def dat_trang_thai_hoat_dong(nut_key):
    for k, nut in nut_menu.items():
        nut.config(bg=MAU_NEN_MENU, fg=MAU_CHU_CHINH)
    nut_menu[nut_key].config(bg=MAU_NUT_NEN, fg="white")

def xu_ly_nhan_menu(key):
    dat_trang_thai_hoat_dong(key)
    hien_thi_khung(key)

danh_muc_menu = [
    ("ThongKe", "📈 Thống kê - Báo cáo"),
    ("QuanLy", "💼 Quản lý"),
    ("GiaoDich", "🤝 Giao dịch"),
    ("KhoHang", "📦 Kho hàng"),
]

for k, nhan in danh_muc_menu:
    nut = tk.Button(menu_ben, text=nhan, font=("Segoe UI", 11), bg=MAU_NEN_MENU, fg=MAU_CHU_CHINH,
                    activebackground=MAU_NUT_HOVER, activeforeground="white", bd=0,
                    command=lambda key=k: xu_ly_nhan_menu(key), anchor="w")
    nut.pack(fill="x", padx=20, pady=6) 
    nut_menu[k] = nut


# Giữ chiều cao banner cố định
khung_banner = tk.Frame(noi_dung_chinh, bg=MAU_NEN_BANNER, height=200, pady=0) 
khung_banner.pack(fill="x", padx=0, pady=(20,20))

global banner_img
banner_img = tk.PhotoImage(file=r"D:\pytidt\QuanLyBanHang\Wallpaper.png")
banner_label = tk.Label(khung_banner, image=banner_img, bg=MAU_NEN_BANNER)
banner_label.image = banner_img # Giữ tham chiếu
banner_label.pack(anchor="center") 
    
khu_vuc_noi_dung = tk.Frame(noi_dung_chinh, bg=MAU_NEN_CHINH)
khu_vuc_noi_dung.pack(fill="both", expand=True, padx=20, pady=(0,20))


# =========================================================================
## Định nghĩa hàm tạo CARD
# =========================================================================

def tao_card(khung_cha, icon, tieu_de, phu_de, command=None):
    # Sử dụng MAU_VIEN_CARD làm màu border
    khung = tk.Frame(khung_cha, bg=MAU_NEN_CARD, relief="solid", bd=2, width=180, height=170, highlightbackground=MAU_VIEN_CARD, highlightthickness=1) 
    khung.pack_propagate(False)

    # Icon (emoji)
    tk.Label(khung, text=icon, font=FONT_ICON, bg=MAU_NEN_CARD, fg=MAU_NHAN).pack(pady=(10, 5)) 

    tk.Label(khung, text=tieu_de, font=FONT_TIEU_DE, bg=MAU_NEN_CARD, fg=MAU_CHU_CHINH).pack() 
    tk.Label(khung, text=phu_de, font=FONT_PHU, fg=MAU_NHAN, bg=MAU_NEN_CARD).pack(pady=(5, 10)) 

    if command:
        khung.bind("<Button-1>", lambda e: command())
        for widget in khung.winfo_children():
            widget.bind("<Button-1>", lambda e: command())

    # Hover effect
    def xu_ly_hover_vao(e):
        khung.config(bg=MAU_CARD_HOVER, bd=2)
    def xu_ly_hover_ra(e):
        khung.config(bg=MAU_NEN_CARD, bd=2)

    # Gắn sự kiện hover cho cả khung và các label con
    khung.bind("<Enter>", xu_ly_hover_vao)
    khung.bind("<Leave>", xu_ly_hover_ra)
    for widget in khung.winfo_children():
        widget.bind("<Enter>", xu_ly_hover_vao)
        widget.bind("<Leave>", xu_ly_hover_ra)

    return khung

# =========================================================================
## HÀM MỚI: Xử lý khi click vào Card 
# =========================================================================

def mo_quan_ly_nhan_vien():
    MoFormQuanLy(cua_so_goc, default_page="NhanVien")

def mo_quan_ly_khach_hang():
    MoFormQuanLy(cua_so_goc, default_page="KhachHang")

def mo_quan_ly_san_pham():
    MoFormQuanLy(cua_so_goc, default_page="SanPham")

def mo_quan_ly_nha_cung_cap():
    MoFormQuanLy(cua_so_goc, default_page="NCC")

# =========================================================================
## XÂY DỰNG CÁC KHUNG NỘI DUNG CHÍNH
# =========================================================================

def tao_bang_dieu_khien(khung):
    # Khung này trống, chỉ có banner ở trên
    pass


def tao_quan_ly(khung): #===========QUẢN LÝ============
    # Header: "Quản lý - Danh mục"
    nhan_tieu_de = ttk.Label(khung, text="Danh mục quản lý", style="Header.TLabel", foreground=MAU_CHU_CHINH, background=MAU_NEN_CHINH)
    nhan_tieu_de.pack(anchor="w", padx=12, pady=12) 

    # Khung chứa các Card
    khung_card = tk.Frame(khung, bg=MAU_NEN_CHINH)
    khung_card.pack(pady=20, padx=12)

    # 4 CARD (Dùng grid để sắp xếp)
    tao_card(khung_card, "👤", "Nhân viên", "Quản lý nhân sự", 
             command=mo_quan_ly_nhan_vien).grid(row=0, column=0, padx=5) 
    tao_card(khung_card, "🙋", "Khách hàng", "Hồ sơ khách hàng",
             command=mo_quan_ly_khach_hang).grid(row=0, column=1, padx=5)
    tao_card(khung_card, "📦", "Sản phẩm", "Danh mục & giá bán",
             command=mo_quan_ly_san_pham).grid(row=0, column=2, padx=5)
    tao_card(khung_card, "🏭", "Nhà cung cấp", "Danh sách NCC",
             command=mo_quan_ly_nha_cung_cap).grid(row=0, column=3, padx=5)



def tao_giao_dich(khung): #===========GIAO DỊCH============
    # Header: "Giao dịch"
    nhan_tieu_de = ttk.Label(khung, text="Giao dịch", style="Header.TLabel", foreground=MAU_CHU_CHINH, background=MAU_NEN_CHINH)
    nhan_tieu_de.pack(anchor="w", padx=12, pady=12) 

    # Khung chứa các Card
    khung_card = tk.Frame(khung, bg=MAU_NEN_CHINH)
    khung_card.pack(pady=20, padx=12)

    # 3 CARD (Dùng grid để sắp xếp)
    tao_card(khung_card, "📝", "Tạo Giao Dịch Mới", "Thực hiện bán hàng",
             command=lambda: MoFormGiaoDich(cua_so_goc, default_page="TaoGiaoDich")
             ).grid(row=0, column=0, padx=20)
    tao_card(khung_card, "🧾", "Hoá đơn", "Xem và quản lý hoá đơn",
             command=lambda: MoFormGiaoDich(cua_so_goc, default_page="HoaDon")
             ).grid(row=0, column=1, padx=20)
    tao_card(khung_card, "🏷️", "Khuyến mãi", "Thiết lập chương trình KM",
             command=lambda: MoFormGiaoDich(cua_so_goc, default_page="KhuyenMai")
             ).grid(row=0, column=2, padx=20)

    
    khung_card.grid_columnconfigure(3, weight=1) 


def tao_kho_hang(khung): #===========KHO HÀNG============
    nhan_tieu_de = ttk.Label(khung, text="Kho hàng", style="Header.TLabel", foreground=MAU_CHU_CHINH, background=MAU_NEN_CHINH)
    nhan_tieu_de.pack(anchor="w", padx=12, pady=12) 

    # Khung chứa các Card
    khung_card = tk.Frame(khung, bg=MAU_NEN_CHINH)
    khung_card.pack(pady=20, padx=12)

    # 3 CARD (Dùng grid để sắp xếp)
    tao_card(khung_card, "📥", "Tạo Phiếu Nhập Hàng", "Lập phiếu nhập kho mới",
             command=lambda: MoFormKhoHang(cua_so_goc, default_page="LapPhieuNhap")
             ).grid(row=0, column=0, padx=20)
    tao_card(khung_card, "📄", "Quản Lý Phiếu Nhập", "Tra cứu và chỉnh sửa phiếu",
             command=lambda: MoFormKhoHang(cua_so_goc, default_page="QuanLyPhieuNhap")
             ).grid(row=0, column=1, padx=20)
    tao_card(khung_card, "📊", "Kiểm Kê Tồn Kho", "Xem số lượng và vị trí tồn",
             command=lambda: MoFormKhoHang(cua_so_goc, default_page="KiemKeTonKho")
             ).grid(row=0, column=2, padx=20)


    khung_card.grid_columnconfigure(3, weight=1)

#==============================================================================================================
def tao_thong_ke(khung): #===========THỐNG KÊ============
    nhan_tieu_de = ttk.Label(
        khung, 
        text="Thống kê - Báo cáo", 
        style="Header.TLabel",
        foreground=MAU_CHU_CHINH, 
        background=MAU_NEN_CHINH
    )
    nhan_tieu_de.pack(anchor="w", padx=12, pady=12)

    # ======== KHUNG CARD THỐNG KÊ TỔNG HỢP ========
    khung_cards = tk.Frame(khung, bg=MAU_NEN_CHINH)
    khung_cards.pack(fill="x", padx=10)

    def mini_card(parent, title, value, icon):
        f = tk.Frame(parent, bg=MAU_NEN_KHUNG, bd=2, relief="solid",
                     highlightbackground=MAU_VIEN_CARD, highlightthickness=1,
                     width=180, height=120)
        f.pack_propagate(False)

        tk.Label(f, text=icon, font=("Segoe UI Emoji", 24),
                 fg=MAU_NHAN, bg=MAU_NEN_KHUNG).pack(pady=(5,0))

        tk.Label(f, text=title, font=("Segoe UI", 10), 
                 fg=MAU_CHU_CHINH, bg=MAU_NEN_KHUNG).pack()

        tk.Label(f, text=value, font=("Segoe UI", 12,"bold"),
                 fg=MAU_NHAN, bg=MAU_NEN_KHUNG).pack()

        return f

    mini_card(khung_cards, "Doanh thu hôm nay", "12.500.000 VNĐ", "💰").grid(row=0, column=0, padx=5, pady=10)
    mini_card(khung_cards, "Số đơn hàng", "38 đơn", "🧾").grid(row=0, column=1, padx=5, pady=10)
    mini_card(khung_cards, "Khách mới", "14 khách", "🙋").grid(row=0, column=2, padx=5, pady=10)
    mini_card(khung_cards, "Sản phẩm tồn kho thấp", "5 mặt hàng", "⚠️").grid(row=0, column=3, padx=5, pady=10)

    # ======== KHUNG BIỂU ĐỒ / BÁO CÁO ========
    khung_bao_cao = tk.Frame(khung, bg=MAU_NEN_CHINH)
    khung_bao_cao.pack(fill="both", expand=True, padx=20, pady=20)

    # --- KHUNG TRÁI: DOANH THU THEO THÁNG ---
    bao_cao_left = tk.Frame(khung_bao_cao, bg=MAU_NEN_KHUNG, bd=2, relief="solid",
                            highlightbackground=MAU_VIEN_CARD, highlightthickness=1)
    bao_cao_left.pack(side="left", fill="both", expand=True, padx=8)
    
    ttk.Label(bao_cao_left, text="Doanh thu theo tháng", style="CardTitle.TLabel",
              background=MAU_NEN_KHUNG).pack(anchor="w", padx=12, pady=12)

    # Số liệu mẫu theo tháng
    ds_thang = ["1","2","3","4","5","6"]
    ds_doanh_thu = ["8.2M", "10.5M", "9.1M", "11.3M", "13.9M", "15.4M"]

    frame_list = tk.Frame(bao_cao_left, bg=MAU_NEN_KHUNG)
    frame_list.pack(padx=12, pady=10, fill="x")

    for thang, doanh_thu in zip(ds_thang, ds_doanh_thu):
        dong = tk.Frame(frame_list, bg=MAU_NEN_KHUNG)
        dong.pack(fill="x", pady=3)

        tk.Label(dong, text=f"Tháng {thang}:",
                 font=("Segoe UI", 10),
                 bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH).pack(side="left")

        tk.Label(dong, text=doanh_thu,
                 font=("Segoe UI", 10, "bold"),
                 bg=MAU_NEN_KHUNG, fg=MAU_NHAN).pack(side="right")

    # --- KHUNG PHẢI: TOP SẢN PHẨM BÁN CHẠY ---
    bao_cao_right = tk.Frame(khung_bao_cao, bg=MAU_NEN_KHUNG, bd=2, relief="solid",
                             highlightbackground=MAU_VIEN_CARD, highlightthickness=1)
    bao_cao_right.pack(side="left", fill="both", expand=True, padx=8)

    ttk.Label(bao_cao_right, text="Top 5 sản phẩm bán chạy", style="CardTitle.TLabel",
              background=MAU_NEN_KHUNG).pack(anchor="w", padx=12, pady=12)

    top_san_pham = [
        ("Laptop Dell Vostro", 128),
        ("Chuột không dây Logitech", 103),
        ("Bàn phím cơ Akko", 96),
        ("Tai nghe Sony WH", 74),
        ("Màn hình LG 24''", 69),
    ]

    frame_sp = tk.Frame(bao_cao_right, bg=MAU_NEN_KHUNG)
    frame_sp.pack(padx=12, pady=10, fill="x")

    for ten, sl in top_san_pham:
        dong = tk.Frame(frame_sp, bg=MAU_NEN_KHUNG)
        dong.pack(fill="x", pady=4)

        tk.Label(dong, text=f"• {ten}",
                 font=("Segoe UI", 10),
                 bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH).pack(side="left", anchor="w")

        tk.Label(dong, text=f"{sl} bán",
                 font=("Segoe UI", 10,"bold"),
                 bg=MAU_NEN_KHUNG, fg=MAU_NHAN).pack(side="right")





# Tạo các trang
cac_trang = {}
cac_trang["Dashboard"] = tk.Frame(khu_vuc_noi_dung, bg=MAU_NEN_CHINH)
cac_trang["QuanLy"] = tk.Frame(khu_vuc_noi_dung, bg=MAU_NEN_CHINH)
cac_trang["GiaoDich"] = tk.Frame(khu_vuc_noi_dung, bg=MAU_NEN_CHINH)
cac_trang["KhoHang"] = tk.Frame(khu_vuc_noi_dung, bg=MAU_NEN_CHINH)
cac_trang["ThongKe"] = tk.Frame(khu_vuc_noi_dung, bg=MAU_NEN_CHINH)

tao_bang_dieu_khien(cac_trang["Dashboard"])
tao_quan_ly(cac_trang["QuanLy"])
tao_giao_dich(cac_trang["GiaoDich"])
tao_kho_hang(cac_trang["KhoHang"])
tao_thong_ke(cac_trang["ThongKe"]) # Thêm hàm tạo khung Thống kê

tk.Frame(menu_ben, bg=MAU_NEN_MENU).pack(fill="both", expand=True)

# Nút Đăng xuất/Thoát
tk.Button(menu_ben, text="Đăng xuất", font=("Segoe UI", 11, "bold"), bg=MAU_NUT_NEN, fg="white", bd=0, command=cua_so_goc.quit, anchor="center").pack(fill="x", padx=20, pady=(0, 30))

# đặt các trang chồng lên nhau
for trang in cac_trang.values():
    trang.place(in_=khu_vuc_noi_dung, x=0, y=0, relwidth=1, relheight=1)

# Hàm hiển thị/ẩn khung
def hien_thi_khung(key):
    anh_xa = {
        "QuanLy": "QuanLy",
        "GiaoDich": "GiaoDich",
        "KhoHang": "KhoHang",
        "ThongKe": "ThongKe",
        "Dash": "Dashboard"
    }
    ten_trang = anh_xa.get(key, "Dashboard")
    trang = cac_trang[ten_trang]
    trang.lift()
    
# Thiết lập nút "Quản lý" (QuanLy) là nút đang active ban đầu.
dat_trang_thai_hoat_dong("ThongKe")
hien_thi_khung("ThongKe")

def show_main_window():
    cua_so_goc.deiconify() # Hiển thị lại cửa sổ đã bị ẩn (withdraw)

if __name__ == "__main__":
    MoFormLogin(cua_so_goc, show_main_window) 
    cua_so_goc.mainloop()

    cua_so_goc.withdraw()
