import tkinter as tk
from tkinter import ttk, messagebox
import pyodbc

def connect():
    try:
        conn = pyodbc.connect(
            'DRIVER={ODBC Driver 17 for SQL Server};'
            'SERVER=DESKTOP-DR4Q3K4;' 
            'DATABASE=QuanLyBanHang;'
            'Trusted_Connection=yes;'
        )
        return conn
    except Exception as e:
        print("Lỗi kết nối SQL Server:", e)
        return None

# ========== HẰNG SỐ MÀU SẮC ĐỒNG BỘ TỪ FORM CHÍNH ==========
MAU_NEN_CHINH = "#0f1720"     # BG
MAU_NEN_MENU = "#132233"    # SIDEBAR_BG
MAU_NEN_KHUNG = "#172433"  # PANEL_BG
MAU_NHAN = "#66AEE9"            # ACCENT
MAU_NUT_NEN = "#25455e"      # BTN_BG
MAU_NUT_HOVER = "#3a6f8e"  # BTN_ACTIVE
MAU_CHU_CHINH = "#eaf2fb"  # TEXT
MAU_NEN_NHAP = "#2b3d47"    # INPUT_BG
MAU_NUT_THOAT = "#F85B50"  # ERROR_BTN
# ==========================================================

# ====== Hàm canh giữa cửa sổ ======
def canh_giua_cua_so(win, w=1000, h=680):
    win.update_idletasks()
    ws = win.winfo_screenwidth()
    hs = win.winfo_screenheight()
    x = (ws // 2) - (w // 2)
    y = (hs // 2) - (h // 2)
    win.geometry(f'{w}x{h}+{x}+{y}')

# ====== Hàm MoFormQuanLy chính ======
def MoFormQuanLy(parent, default_page="NhanVien"):

    cua_so_con = tk.Toplevel(parent)
    cua_so_con.title("Quản lý bán hàng")
    cua_so_con.config(bg=MAU_NEN_CHINH)
    canh_giua_cua_so(cua_so_con, 1000, 680)
    cua_so_con.resizable(False, False)

    # ========== KHUNG CHÍNH: MenuBen & NoiDungChinh ==========
    menu_ben = tk.Frame(cua_so_con, bg=MAU_NEN_MENU, width=200)
    menu_ben.pack(side="left", fill="y")
    noi_dung_chinh = tk.Frame(cua_so_con, bg=MAU_NEN_CHINH)
    noi_dung_chinh.pack(side="left", fill="both", expand=True)

    # ===== MenuBen content (Icon & TenUngDung) =====
    icon_ung_dung = tk.Label(menu_ben, text="🛒", bg=MAU_NEN_MENU, fg=MAU_NHAN, font=("Segoe UI", 25))
    icon_ung_dung.pack(pady=(18,6))
    ten_ung_dung = tk.Label(menu_ben, text="QUẢN LÝ\nBÁN HÀNG\n", bg=MAU_NEN_MENU, fg=MAU_CHU_CHINH, font=("Segoe UI", 12, "bold"), justify="center")
    ten_ung_dung.pack(pady=(0,18))
    tieu_de_menu = tk.Label(menu_ben, text="Quản lý danh mục", bg=MAU_NEN_MENU, fg="#9fb8c9", font=("Segoe UI", 9, "bold"))
    tieu_de_menu.pack(anchor="w", padx=30, pady=(6,2))

    # ====== TẠO CÁC KHUNG NỘI DUNG (PAGE FRAMES) ======
    noi_dung_nhanvien = tk.Frame(noi_dung_chinh, bg=MAU_NEN_CHINH)
    noi_dung_khachhang = tk.Frame(noi_dung_chinh, bg=MAU_NEN_CHINH)
    noi_dung_sanpham = tk.Frame(noi_dung_chinh, bg=MAU_NEN_CHINH)
    noi_dung_ncc = tk.Frame(noi_dung_chinh, bg=MAU_NEN_CHINH)

    # Place them to overlap, we'll raise the active one
    for fr in (noi_dung_nhanvien, noi_dung_khachhang, noi_dung_sanpham, noi_dung_ncc):
        fr.place(relx=0, rely=0, relwidth=1, relheight=1)
    
    def hien_thi_trang(trang):
        trang.tkraise()

    # Sidebar buttons logic
    nut_menu = {}

    def dat_trang_thai_hoat_dong(nut_key):
        for k, nut in nut_menu.items():
            nut.config(bg=MAU_NEN_MENU, fg=MAU_CHU_CHINH)
        if nut_key in nut_menu:
            nut_menu[nut_key].config(bg=MAU_NUT_NEN, fg="white")

    def xu_ly_nhan_menu(key):
        dat_trang_thai_hoat_dong(key)
        if key == "NhanVien":
            hien_thi_trang(noi_dung_nhanvien)
        elif key == "KhachHang":
            hien_thi_trang(noi_dung_khachhang)
        elif key == "SanPham":
            hien_thi_trang(noi_dung_sanpham)
        elif key == "NCC":
            hien_thi_trang(noi_dung_ncc)

    danh_muc_menu = [
        ("NhanVien", "👤 Nhân viên"),
        ("KhachHang", "🙋 Khách hàng"),
        ("SanPham", "📦 Sản phẩm"),
        ("NCC", "🏭 Nhà cung cấp"),
    ]

    for k, nhan in danh_muc_menu:
        nut = tk.Button(menu_ben, text=nhan, font=("Segoe UI", 11), bg=MAU_NEN_MENU, fg=MAU_CHU_CHINH,
                        activebackground=MAU_NUT_HOVER, activeforeground="white", bd=0,
                        command=lambda key=k: xu_ly_nhan_menu(key), anchor="w")
        nut.pack(fill="x", padx=20, pady=6)
        nut_menu[k] = nut

    tk.Frame(menu_ben, bg=MAU_NEN_MENU).pack(fill="both", expand=True) # Spacer

    # FONT
    FONT_TIEU_DE_LON = ("Segoe UI", 20, "bold")
    FONT_NHAN = ("Segoe UI", 10)
    FONT_NUT = ("Segoe UI", 10, "bold")
    FONT_TIEU_DE_NHO = ("Segoe UI", 12, "bold")
#===============================================================================
# FORM NHÂN VIÊN
#===============================================================================
    def xay_dung_nhanvien(khung_cha):
        MaNV = tk.StringVar()
        HoLot = tk.StringVar()
        TenNV = tk.StringVar() # Biến cho form nhập liệu
        GioiTinh = tk.StringVar(value='Nam')
        NgaySinh = tk.StringVar()
        ChucVu = tk.StringVar(value='Nhân viên')
        
        TenNV_TimKiem = tk.StringVar() 

        khung_tieu_de = tk.Frame(khung_cha, bg=MAU_NEN_CHINH)
        khung_tieu_de.pack(pady=10, padx=10, fill='x')
        tk.Label(khung_tieu_de, text="QUẢN LÝ NHÂN VIÊN", font=FONT_TIEU_DE_LON, bg=MAU_NEN_CHINH, fg=MAU_NHAN).pack(expand=True,pady=15)

        #KHUNG NHẬP LIỆU
        khung_nhap_lieu = tk.Frame(khung_cha, bg=MAU_NEN_KHUNG)
        khung_nhap_lieu.pack(fill='x', padx=20, pady=10)

        # Cài đặt Treeview
        cot = ("Mã nhân viên", "Họ lót", "Tên", "Giới tính", "Ngày sinh", "Chức vụ")
        bang_nv = ttk.Treeview(khung_cha, columns=cot, show="headings", height=10)
        # Style Treeview
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview",
                              background=MAU_NEN_KHUNG,
                              foreground=MAU_CHU_CHINH,
                              fieldbackground=MAU_NEN_KHUNG,
                              rowheight=25)
        style.map('Treeview', background=[('selected', MAU_NUT_NEN)])

        style.configure("Treeview.Heading",
                              background=MAU_NUT_NEN,
                              foreground=MAU_CHU_CHINH,
                              font=('Segoe UI', 10, 'bold'),
                              relief="flat")
        
        def tao_nhan(khung_cha_local, text, row, column, sticky='w'):
            tk.Label(khung_cha_local, text=text, font=FONT_NHAN,
                      bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH).grid(row=row, column=column, padx=5, pady=5, sticky=sticky)
        
        def tao_o_nhap(khung_cha_local, textvariable, width, row, column, sticky='w'):
            tk.Entry(khung_cha_local, textvariable=textvariable, font=FONT_NHAN, width=width,
                      bg=MAU_NEN_NHAP, fg=MAU_CHU_CHINH, insertbackground=MAU_CHU_CHINH, bd=0).grid(row=row, column=column, padx=5, pady=5, sticky=sticky)

        # CHỨC NĂNG CRUD ==================================================
        def xoa_nhap_lieu():
            MaNV.set("")
            HoLot.set("")
            TenNV.set("")
            GioiTinh.set("Nam")
            NgaySinh.set("")
            ChucVu.set("Nhân viên")

        def load_nv(search_term=None):
            for row in bang_nv.get_children():
                bang_nv.delete(row)
            conn = connect()
            if conn is None: return 
            
            try:
                cur = conn.cursor()
                sql = "SELECT MaNV, HoLot, TenNV, GioiTinh, NgaySinh, ChucVu FROM NhanVien"
                params = []

                if search_term:
                    sql += " WHERE TenNV LIKE ?"
                    params.append(f'%{search_term}%')

                cur.execute(sql, params)
                
                for row in cur.fetchall():
                    data_list = list(row) 
                    if data_list[4]:
                        try:
                            data_list[4] = data_list[4].strftime('%Y-%m-%d')
                        except AttributeError:
                            data_list[4] = str(data_list[4])
                            
                    bang_nv.insert("", tk.END, values=data_list)
            except Exception as e:
                messagebox.showerror("Lỗi SQL", f"Không thể tải dữ liệu nhân viên:\n{e}")
            finally:
                if conn:
                    conn.close()

        def them_nv():
            if not all([MaNV.get(), HoLot.get(), TenNV.get()]):
                messagebox.showwarning("Thiếu dữ liệu", "Vui lòng nhập đủ Mã NV, Họ lót và Tên!")
                return
            conn = connect()
            if conn is None: return
            cur = conn.cursor()
            try:
                cur.execute(
                    "INSERT INTO NhanVien (MaNV, HoLot, TenNV, GioiTinh, NgaySinh, ChucVu) VALUES (?, ?, ?, ?, ?, ?)",
                    (MaNV.get(), HoLot.get(), TenNV.get(),
                    GioiTinh.get(), NgaySinh.get(), ChucVu.get())
                )
                conn.commit()
                load_nv()
                xoa_nhap_lieu()
                messagebox.showinfo("Thành công", "Đã thêm nhân viên mới.")
            except pyodbc.IntegrityError:
                messagebox.showerror("Lỗi Dữ Liệu", "Mã nhân viên đã tồn tại hoặc dữ liệu không hợp lệ.")
            except Exception as e:
                messagebox.showerror("Lỗi", str(e))
            finally:
                conn.close()

        def xoa_nv():
            selected = bang_nv.selection()
            if not selected:
                messagebox.showwarning("Chưa chọn", "Hãy chọn dòng để xoá")
                return
            
            maso = bang_nv.item(selected[0])["values"][0] # Lấy mã NV từ dòng được chọn
            if not messagebox.askyesno("Xác nhận xoá", f"Bạn có chắc chắn muốn xoá nhân viên có mã {maso}?"):
                return
                
            conn = connect()
            if conn is None: return
            cur = conn.cursor()
            try:
                cur.execute("DELETE FROM NhanVien WHERE MaNV = ?", maso)
                conn.commit()
                load_nv()
                messagebox.showinfo("Thành công", f"Đã xoá nhân viên mã {maso}.")
            except Exception as e:
                messagebox.showerror("Lỗi", f"Không thể xoá nhân viên:\n{e}")
            finally:
                conn.close()

        def sua_nv():
            selected = bang_nv.selection()
            if not selected:
                messagebox.showwarning("Chưa chọn", "Hãy chọn dòng cần sửa")
                return
            # Load dữ liệu từ Treeview lên form
            data = bang_nv.item(selected[0])["values"]
            MaNV.set(data[0])
            HoLot.set(data[1])
            TenNV.set(data[2])
            GioiTinh.set(data[3])
            NgaySinh.set(data[4])
            ChucVu.set(data[5])
            # Khóa Mã NV khi sửa
            MaNV_Entry.config(state='readonly')

        # LƯU SAU KHI SỬA
        def luu_nv():
            if not all([MaNV.get(), HoLot.get(), TenNV.get()]):
                messagebox.showwarning("Thiếu dữ liệu", "Vui lòng nhập đủ thông tin!")
                return
            conn = connect()
            if conn is None: return
            cur = conn.cursor()
            try:
                cur.execute("""
                    UPDATE NhanVien
                    SET HoLot=?, TenNV=?, GioiTinh=?, NgaySinh=?, ChucVu=?
                    WHERE MaNV=?
                """, (HoLot.get(), TenNV.get(), GioiTinh.get(),
                    NgaySinh.get(), ChucVu.get(), MaNV.get()))
                conn.commit()
                load_nv()
                xoa_nhap_lieu()
                MaNV_Entry.config(state='normal') # Mở khóa Mã NV
                messagebox.showinfo("Thành công", f"Đã cập nhật nhân viên mã {MaNV.get()}.")
            except Exception as e:
                messagebox.showerror("Lỗi", f"Không thể lưu cập nhật:\n{e}")
            finally:
                conn.close()
        
        def tim_kiem_nv():
            search_term = TenNV_TimKiem.get().strip() 
            if not search_term:
                messagebox.showwarning("Tìm kiếm", "Vui lòng nhập tên nhân viên để tìm kiếm.")
                return
            load_nv(search_term)

        def hien_thi_tat_ca_nv():
            TenNV_TimKiem.set("") 
            load_nv(search_term=None)
        
        # --- Bố cục KHUNG NHẬP LIỆU ---
        # Hàng 1
        tao_nhan(khung_nhap_lieu, "Mã NV:", 0, 0)
        MaNV_Entry = tk.Entry(khung_nhap_lieu, textvariable=MaNV, font=FONT_NHAN, width=15,
                        bg=MAU_NEN_NHAP, fg=MAU_CHU_CHINH, insertbackground=MAU_CHU_CHINH, bd=0)
        MaNV_Entry.grid(row=0, column=1, padx=5, pady=5, sticky='w')
        
        tao_nhan(khung_nhap_lieu, "Giới tính:", 0, 3)
        tk.Radiobutton(khung_nhap_lieu, text="Nam", variable=GioiTinh, value="Nam",
                        bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH, selectcolor=MAU_NEN_CHINH, activebackground=MAU_NEN_KHUNG, activeforeground=MAU_NHAN).grid(row=0, column=4, sticky='w')
        tk.Radiobutton(khung_nhap_lieu, text="Nữ", variable=GioiTinh, value="Nữ",
                        bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH, selectcolor=MAU_NEN_CHINH, activebackground=MAU_NEN_KHUNG, activeforeground=MAU_NHAN).grid(row=0, column=5, sticky='w')
        # Hàng 2
        tao_nhan(khung_nhap_lieu, "Họ và lót:", 1, 0)
        tao_o_nhap(khung_nhap_lieu, HoLot, 25, 1, 1)
        tao_nhan(khung_nhap_lieu, "Tên:", 1, 3)
        tao_o_nhap(khung_nhap_lieu, TenNV, 15, 1, 4) # Sử dụng biến TenNV cho form
        # Hàng 3
        tao_nhan(khung_nhap_lieu, "Ngày sinh:", 2, 0)
        tao_o_nhap(khung_nhap_lieu, NgaySinh, 15, 2, 1)
        tao_nhan(khung_nhap_lieu, "Chức vụ:", 2, 3)
        combo_style = ttk.Style()
        combo_style.theme_use("clam")
        combo_style.configure("TCombobox", fieldbackground=MAU_NEN_NHAP, background=MAU_NEN_NHAP, foreground=MAU_CHU_CHINH, selectbackground=MAU_NEN_NHAP, selectforeground=MAU_CHU_CHINH, bordercolor=MAU_NEN_NHAP)
        ttk.Combobox(khung_nhap_lieu, textvariable=ChucVu,
                      values=["Giám đốc", "Quản lý", "Nhân viên", "Kế toán"],
                      state="readonly", width=15, style="TCombobox").grid(row=2, column=4, padx=5, pady=5, sticky='w')
        # NÚT CHỨC NĂNG CRUD
        lenh_nut_chuc_nang = {
            "Thêm": them_nv, "Sửa": sua_nv, "Xoá": xoa_nv,
            "Lưu": luu_nv, "Huỷ": xoa_nhap_lieu, "Thoát": cua_so_con.destroy
        }
        vi_tri_nut = [(0, 7), (1, 7), (2, 7), (0, 8), (1, 8), (2, 8)]
        nhan_nut = ["Thêm", "Sửa", "Xoá", "Lưu", "Huỷ", "Thoát"]

        for nhan, (r, c) in zip(nhan_nut, vi_tri_nut):
            nen_nut = MAU_NUT_NEN if nhan != "Thoát" else MAU_NUT_THOAT
            tk.Button(khung_nhap_lieu, text=nhan, font=FONT_NUT, bg=nen_nut, fg=MAU_CHU_CHINH,
                        relief="flat", width=12, command=lenh_nut_chuc_nang[nhan],
                        activebackground=MAU_NHAN, activeforeground=MAU_NEN_CHINH).grid(row=r, column=c, padx=12, pady=5)


        # 5. KHUNG TÌM KIẾM
        khung_tim_kiem = tk.Frame(khung_cha, bg=MAU_NEN_KHUNG)
        khung_tim_kiem.pack(fill='x', padx=20, pady=10)
        tao_nhan(khung_tim_kiem, "Nhập tên nhân viên:", 0, 0)
        tao_o_nhap(khung_tim_kiem, TenNV_TimKiem, 15, 0, 1) 
        # NÚT TÌM KIẾM
        tk.Button(khung_tim_kiem, text="Tìm kiếm", font=("Segoe UI", 8, "bold"),
                  bg=MAU_NUT_NEN, fg=MAU_CHU_CHINH, relief="raised",
                  width=10, activebackground=MAU_NHAN, activeforeground=MAU_NEN_CHINH,
                  command=tim_kiem_nv # <--- Gán hàm tìm kiếm
                  ).grid(row=0, column=2, padx=8)    
        # NÚT HIỂN THỊ TẤT CẢ
        tk.Button(khung_tim_kiem, text="Hiển thị tất cả", font=("Segoe UI", 8, "bold"),
                  bg=MAU_NUT_NEN, fg=MAU_CHU_CHINH, relief="raised",
                  width=12, activebackground=MAU_NHAN, activeforeground=MAU_NEN_CHINH,
                  command=hien_thi_tat_ca_nv # <--- Gán hàm hiển thị tất cả
                  ).grid(row=0, column=3, padx=8)

        # 6. DANH SÁCH NHÂN VIÊN (TREEVIEW)
        tk.Label(khung_cha, text="DANH SÁCH NHÂN VIÊN", font=FONT_TIEU_DE_NHO, fg=MAU_NHAN, bg=MAU_NEN_CHINH).pack(pady=5)
        
        for c in cot:
            bang_nv.heading(c, text=c.capitalize())
        bang_nv.column("Mã nhân viên", width=80, anchor="center")
        bang_nv.column("Họ lót", width=150)
        bang_nv.column("Tên", width=100)
        bang_nv.column("Giới tính", width=70, anchor="center")
        bang_nv.column("Ngày sinh", width=100, anchor="center")
        bang_nv.column("Chức vụ", width=150, anchor="center")

        bang_nv.pack(padx=20, pady=5, fill="both", expand=True)

        # Tải dữ liệu ban đầu
        load_nv()

#===============================================================================
# FORM KHÁCH HÀNG
#===============================================================================
    def xay_dung_khachhang(khung_cha):
        MaKH = tk.StringVar()
        HoLot = tk.StringVar()
        TenKH = tk.StringVar()  # Biến cho form nhập liệu
        GioiTinh = tk.StringVar(value='Nam')
        NgaySinhKH = tk.StringVar()
        Sdt = tk.StringVar()
        
        TenKH_TimKiem = tk.StringVar()

        # Khung tiêu đề
        khung_tieu_de = tk.Frame(khung_cha, bg=MAU_NEN_CHINH)
        khung_tieu_de.pack(pady=10, padx=10, fill='x')
        tk.Label(khung_tieu_de, text="QUẢN LÝ KHÁCH HÀNG", font=FONT_TIEU_DE_LON, bg=MAU_NEN_CHINH, fg=MAU_NHAN).pack(expand=True,pady=15)

        # Khung nhập liệu
        khung_nhap_lieu = tk.Frame(khung_cha, bg=MAU_NEN_KHUNG)
        khung_nhap_lieu.pack(fill='x', padx=20, pady=10)

        # Treeview
        cot = ("Mã KH", "Họ lót", "Tên", "Giới tính", "Ngày sinh", "SĐT")
        bang_kh = ttk.Treeview(khung_cha, columns=cot, show="headings", height=10)

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview",
                        background=MAU_NEN_KHUNG,
                        foreground=MAU_CHU_CHINH,
                        fieldbackground=MAU_NEN_KHUNG,
                        rowheight=25)
        style.map('Treeview', background=[('selected', MAU_NUT_NEN)])
        style.configure("Treeview.Heading",
                        background=MAU_NUT_NEN,
                        foreground=MAU_CHU_CHINH,
                        font=('Segoe UI', 10, 'bold'),
                        relief="flat")

        # Hàm tạo nhãn và ô nhập
        def tao_nhan(khung, text, row, col, sticky='w'):
            tk.Label(khung, text=text, font=FONT_NHAN, bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH).grid(row=row, column=col, padx=5, pady=5, sticky=sticky)

        def tao_o_nhap(khung, textvariable, width, row, col, sticky='w'):
            tk.Entry(khung, textvariable=textvariable, font=FONT_NHAN, width=width,
                    bg=MAU_NEN_NHAP, fg=MAU_CHU_CHINH, insertbackground=MAU_CHU_CHINH, bd=0).grid(row=row, column=col, padx=5, pady=5, sticky=sticky)

        # ---------- CRUD ----------
        def xoa_nhap_lieu():
            MaKH.set("")
            HoLot.set("")
            TenKH.set("")
            GioiTinh.set("Nam")
            NgaySinhKH.set("")
            Sdt.set("")

        def load_kh(search_term=None):
            for row in bang_kh.get_children():
                bang_kh.delete(row)
            conn = connect()
            if conn is None: return
            try:
                cur = conn.cursor()
                sql = "SELECT MaKH, HoLot, TenKH, GioiTinh, NgaySinh, Sdt FROM KhachHang"
                params = []
                if search_term:
                    sql += " WHERE TenKH LIKE ?"
                    params.append(f'%{search_term}%')
                cur.execute(sql, params)
                for row in cur.fetchall():
                    data_list = list(row)
                    if data_list[4]:
                        try:
                            data_list[4] = data_list[4].strftime('%Y-%m-%d')
                        except AttributeError:
                            data_list[4] = str(data_list[4])
                    bang_kh.insert("", tk.END, values=data_list)
            except Exception as e:
                messagebox.showerror("Lỗi SQL", f"Không thể tải dữ liệu khách hàng:\n{e}")
            finally:
                if conn: conn.close()

        def them_kh():
            if not all([MaKH.get(), HoLot.get(), TenKH.get()]):
                messagebox.showwarning("Thiếu dữ liệu", "Vui lòng nhập đủ Mã KH, Họ lót và Tên!")
                return
            conn = connect()
            if conn is None: return
            try:
                cur = conn.cursor()
                cur.execute(
                    "INSERT INTO KhachHang (MaKH, HoLot, TenKH, GioiTinh, NgaySinh, Sdt) VALUES (?, ?, ?, ?, ?, ?)",
                    (MaKH.get(), HoLot.get(), TenKH.get(), GioiTinh.get(), NgaySinhKH.get(), Sdt.get())
                )
                conn.commit()
                load_kh()
                xoa_nhap_lieu()
                messagebox.showinfo("Thành công", "Đã thêm khách hàng mới.")
            except Exception as e:
                messagebox.showerror("Lỗi", str(e))
            finally:
                conn.close()

        def xoa_kh():
            selected = bang_kh.selection()
            if not selected:
                messagebox.showwarning("Chưa chọn", "Hãy chọn dòng để xoá")
                return
            maso = bang_kh.item(selected[0])["values"][0]
            if not messagebox.askyesno("Xác nhận xoá", f"Bạn có chắc chắn muốn xoá khách hàng mã {maso}?"):
                return
            conn = connect()
            if conn is None: return
            try:
                cur = conn.cursor()
                cur.execute("DELETE FROM KhachHang WHERE MaKH = ?", maso)
                conn.commit()
                load_kh()
                messagebox.showinfo("Thành công", f"Đã xoá khách hàng mã {maso}.")
            finally:
                conn.close()

        def sua_kh():
            selected = bang_kh.selection()
            if not selected:
                messagebox.showwarning("Chưa chọn", "Hãy chọn dòng cần sửa")
                return
            data = bang_kh.item(selected[0])["values"]
            MaKH.set(data[0])
            HoLot.set(data[1])
            TenKH.set(data[2])
            GioiTinh.set(data[3])
            NgaySinhKH.set(data[4])
            Sdt.set(data[5])
            MaKH_Entry.config(state='readonly')

        def luu_kh():
            if not all([MaKH.get(), HoLot.get(), TenKH.get()]):
                messagebox.showwarning("Thiếu dữ liệu", "Vui lòng nhập đủ thông tin!")
                return
            conn = connect()
            if conn is None: return
            try:
                cur = conn.cursor()
                cur.execute("""
                    UPDATE KhachHang
                    SET HoLot=?, TenKH=?, GioiTinh=?, NgaySinh=?, Sdt=?
                    WHERE MaKH=?
                """, (HoLot.get(), TenKH.get(), GioiTinh.get(), NgaySinhKH.get(), Sdt.get(), MaKH.get()))
                conn.commit()
                load_kh()
                xoa_nhap_lieu()
                MaKH_Entry.config(state='normal')
                messagebox.showinfo("Thành công", f"Đã cập nhật khách hàng mã {MaKH.get()}.")
            finally:
                conn.close()

        def tim_kiem_kh():
            search_term = TenKH_TimKiem.get().strip()
            if not search_term:
                messagebox.showwarning("Tìm kiếm", "Vui lòng nhập tên khách hàng để tìm kiếm.")
                return
            load_kh(search_term)

        def hien_thi_tat_ca_kh():
            TenKH_TimKiem.set("")
            load_kh()

        # --- Bố cục KHUNG NHẬP LIỆU ---
        tao_nhan(khung_nhap_lieu, "Mã KH:", 0, 0)
        MaKH_Entry = tk.Entry(khung_nhap_lieu, textvariable=MaKH, font=FONT_NHAN, width=15,
                            bg=MAU_NEN_NHAP, fg=MAU_CHU_CHINH, insertbackground=MAU_CHU_CHINH, bd=0)
        MaKH_Entry.grid(row=0, column=1, padx=5, pady=5, sticky='w')

        tao_nhan(khung_nhap_lieu, "Giới tính:", 0, 3)
        tk.Radiobutton(khung_nhap_lieu, text="Nam", variable=GioiTinh, value="Nam",
                    bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH, selectcolor=MAU_NEN_CHINH).grid(row=0, column=4, sticky='w')
        tk.Radiobutton(khung_nhap_lieu, text="Nữ", variable=GioiTinh, value="Nữ",
                    bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH, selectcolor=MAU_NEN_CHINH).grid(row=0, column=5, sticky='w')

        tao_nhan(khung_nhap_lieu, "Họ và lót:", 1, 0)
        tao_o_nhap(khung_nhap_lieu, HoLot, 25, 1, 1)
        tao_nhan(khung_nhap_lieu, "Tên:", 1, 3)
        tao_o_nhap(khung_nhap_lieu, TenKH, 15, 1, 4)

        tao_nhan(khung_nhap_lieu, "Ngày sinh:", 2, 0)
        tao_o_nhap(khung_nhap_lieu, NgaySinhKH, 15, 2, 1)
        tao_nhan(khung_nhap_lieu, "SĐT:", 2, 3)
        tao_o_nhap(khung_nhap_lieu, Sdt, 15, 2, 4)

        # Nút CRUD
        lenh_nut_chuc_nang = {
            "Thêm": them_kh, "Sửa": sua_kh, "Xoá": xoa_kh,
            "Lưu": luu_kh, "Huỷ": xoa_nhap_lieu, "Thoát": cua_so_con.destroy
        }
        vi_tri_nut = [(0, 7), (1, 7), (2, 7), (0, 8), (1, 8), (2, 8)]
        nhan_nut = ["Thêm", "Sửa", "Xoá", "Lưu", "Huỷ", "Thoát"]

        for nhan, (r, c) in zip(nhan_nut, vi_tri_nut):
            nen_nut = MAU_NUT_NEN if nhan != "Thoát" else MAU_NUT_THOAT
            tk.Button(khung_nhap_lieu, text=nhan, font=FONT_NUT, bg=nen_nut, fg=MAU_CHU_CHINH,
                    relief="flat", width=12, command=lenh_nut_chuc_nang[nhan],
                    activebackground=MAU_NHAN, activeforeground=MAU_NEN_CHINH).grid(row=r, column=c, padx=12, pady=5)

        # Khung tìm kiếm
        khung_tim_kiem = tk.Frame(khung_cha, bg=MAU_NEN_KHUNG)
        khung_tim_kiem.pack(fill='x', padx=20, pady=10)
        tao_nhan(khung_tim_kiem, "Nhập tên khách hàng:", 0, 0)
        tao_o_nhap(khung_tim_kiem, TenKH_TimKiem, 15, 0, 1)
        tk.Button(khung_tim_kiem, text="Tìm kiếm", font=("Segoe UI", 8, "bold"),
                bg=MAU_NUT_NEN, fg=MAU_CHU_CHINH, relief="raised",
                width=10, command=tim_kiem_kh).grid(row=0, column=2, padx=8)
        tk.Button(khung_tim_kiem, text="Hiển thị tất cả", font=("Segoe UI", 8, "bold"),
                bg=MAU_NUT_NEN, fg=MAU_CHU_CHINH, relief="raised",
                width=12, command=hien_thi_tat_ca_kh).grid(row=0, column=3, padx=8)

        # Treeview danh sách khách hàng
        tk.Label(khung_cha, text="DANH SÁCH KHÁCH HÀNG", font=FONT_TIEU_DE_NHO, fg=MAU_NHAN, bg=MAU_NEN_CHINH).pack(pady=5)
        for c in cot:
            bang_kh.heading(c, text=c.capitalize())
        bang_kh.column("Mã KH", width=80, anchor="center")
        bang_kh.column("Họ lót", width=150)
        bang_kh.column("Tên", width=100)
        bang_kh.column("Giới tính", width=70, anchor="center")
        bang_kh.column("Ngày sinh", width=100, anchor="center")
        bang_kh.column("SĐT", width=120, anchor="center")
        bang_kh.pack(padx=20, pady=5, fill="both", expand=True)

        # Load dữ liệu ban đầu
        load_kh()

#===============================================================================
# FORM SẢN PHẨM
#===============================================================================
    def xay_dung_sanpham(khung_cha):
        MaSP = tk.StringVar()
        TenSP = tk.StringVar()
        LoaiSP = tk.StringVar()
        DonViTinh = tk.StringVar()
        DonGiaBan = tk.StringVar()
        TonKho = tk.StringVar()
        
        TenSP_TimKiem = tk.StringVar()

        # Khung tiêu đề
        khung_tieu_de = tk.Frame(khung_cha, bg=MAU_NEN_CHINH)
        khung_tieu_de.pack(pady=10, padx=10, fill='x')
        tk.Label(khung_tieu_de, text="QUẢN LÝ SẢN PHẨM", font=FONT_TIEU_DE_LON, bg=MAU_NEN_CHINH, fg=MAU_NHAN).pack(expand=True,pady=15)

        # Khung nhập liệu
        khung_nhap_lieu = tk.Frame(khung_cha, bg=MAU_NEN_KHUNG)
        khung_nhap_lieu.pack(fill='x', padx=20, pady=10)

        # Treeview
        cot = ("Mã SP", "Tên SP", "Loại SP", "Đơn vị", "Đơn giá", "Tồn kho")
        bang_sp = ttk.Treeview(khung_cha, columns=cot, show="headings", height=10)

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview",
                        background=MAU_NEN_KHUNG,
                        foreground=MAU_CHU_CHINH,
                        fieldbackground=MAU_NEN_KHUNG,
                        rowheight=25)
        style.map('Treeview', background=[('selected', MAU_NUT_NEN)])
        style.configure("Treeview.Heading",
                        background=MAU_NUT_NEN,
                        foreground=MAU_CHU_CHINH,
                        font=('Segoe UI', 10, 'bold'),
                        relief="flat")

        # Hàm tạo nhãn và ô nhập
        def tao_nhan(khung, text, row, col, sticky='w'):
            tk.Label(khung, text=text, font=FONT_NHAN, bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH).grid(row=row, column=col, padx=5, pady=5, sticky=sticky)

        def tao_o_nhap(khung, textvariable, width, row, col, sticky='w'):
            tk.Entry(khung, textvariable=textvariable, font=FONT_NHAN, width=width,
                    bg=MAU_NEN_NHAP, fg=MAU_CHU_CHINH, insertbackground=MAU_CHU_CHINH, bd=0).grid(row=row, column=col, padx=5, pady=5, sticky=sticky)

        # ---------- CRUD ----------
        def xoa_nhap_lieu():
            MaSP.set("")
            TenSP.set("")
            LoaiSP.set("")
            DonViTinh.set("")
            DonGiaBan.set("")
            TonKho.set("")

        def load_sp(search_term=None):
            for row in bang_sp.get_children():
                bang_sp.delete(row)
            conn = connect()
            if conn is None: return
            try:
                cur = conn.cursor()
                sql = "SELECT MaSP, TenSP, LoaiSP, DonViTinh, DonGiaBan, TonKho FROM SanPham"
                params = []
                if search_term:
                    sql += " WHERE TenSP LIKE ?"
                    params.append(f'%{search_term}%')
                cur.execute(sql, params)
                for row in cur.fetchall():
                    data_list = list(row)
                    bang_sp.insert("", tk.END, values=data_list)
            except Exception as e:
                messagebox.showerror("Lỗi SQL", f"Không thể tải dữ liệu sản phẩm:\n{e}")
            finally:
                if conn: conn.close()

        def them_sp():
            if not all([MaSP.get(), TenSP.get()]):
                messagebox.showwarning("Thiếu dữ liệu", "Vui lòng nhập Mã SP và Tên SP!")
                return
            conn = connect()
            if conn is None: return
            try:
                cur = conn.cursor()
                cur.execute(
                    "INSERT INTO SanPham (MaSP, TenSP, LoaiSP, DonViTinh, DonGiaBan, TonKho) VALUES (?, ?, ?, ?, ?, ?)",
                    (MaSP.get(), TenSP.get(), LoaiSP.get(), DonViTinh.get(), DonGiaBan.get(), TonKho.get())
                )
                conn.commit()
                load_sp()
                xoa_nhap_lieu()
                messagebox.showinfo("Thành công", "Đã thêm sản phẩm mới.")
            except Exception as e:
                messagebox.showerror("Lỗi", str(e))
            finally:
                conn.close()

        def xoa_sp():
            selected = bang_sp.selection()
            if not selected:
                messagebox.showwarning("Chưa chọn", "Hãy chọn dòng để xoá")
                return
            maso = bang_sp.item(selected[0])["values"][0]
            if not messagebox.askyesno("Xác nhận xoá", f"Bạn có chắc chắn muốn xoá sản phẩm mã {maso}?"):
                return
            conn = connect()
            if conn is None: return
            try:
                cur = conn.cursor()
                cur.execute("DELETE FROM SanPham WHERE MaSP = ?", maso)
                conn.commit()
                load_sp()
                messagebox.showinfo("Thành công", f"Đã xoá sản phẩm mã {maso}.")
            finally:
                conn.close()

        def sua_sp():
            selected = bang_sp.selection()
            if not selected:
                messagebox.showwarning("Chưa chọn", "Hãy chọn dòng cần sửa")
                return
            data = bang_sp.item(selected[0])["values"]
            MaSP.set(data[0])
            TenSP.set(data[1])
            LoaiSP.set(data[2])
            DonViTinh.set(data[3])
            DonGiaBan.set(data[4])
            TonKho.set(data[5])
            MaSP_Entry.config(state='readonly')

        def luu_sp():
            if not all([MaSP.get(), TenSP.get()]):
                messagebox.showwarning("Thiếu dữ liệu", "Vui lòng nhập đầy đủ thông tin!")
                return
            conn = connect()
            if conn is None: return
            try:
                cur = conn.cursor()
                cur.execute("""
                    UPDATE SanPham
                    SET TenSP=?, LoaiSP=?, DonViTinh=?, DonGiaBan=?, TonKho=?
                    WHERE MaSP=?
                """, (TenSP.get(), LoaiSP.get(), DonViTinh.get(), DonGiaBan.get(), TonKho.get(), MaSP.get()))
                conn.commit()
                load_sp()
                xoa_nhap_lieu()
                MaSP_Entry.config(state='normal')
                messagebox.showinfo("Thành công", f"Đã cập nhật sản phẩm mã {MaSP.get()}.")
            finally:
                conn.close()

        def tim_kiem_sp():
            search_term = TenSP_TimKiem.get().strip()
            if not search_term:
                messagebox.showwarning("Tìm kiếm", "Vui lòng nhập tên sản phẩm để tìm kiếm.")
                return
            load_sp(search_term)

        def hien_thi_tat_ca_sp():
            TenSP_TimKiem.set("")
            load_sp()

        # --- Bố cục KHUNG NHẬP LIỆU ---
        tao_nhan(khung_nhap_lieu, "Mã SP:", 0, 0)
        MaSP_Entry = tk.Entry(khung_nhap_lieu, textvariable=MaSP, font=FONT_NHAN, width=15,
                            bg=MAU_NEN_NHAP, fg=MAU_CHU_CHINH, insertbackground=MAU_CHU_CHINH, bd=0)
        MaSP_Entry.grid(row=0, column=1, padx=5, pady=5, sticky='w')

        tao_nhan(khung_nhap_lieu, "Loại SP:", 0, 3)
        tao_o_nhap(khung_nhap_lieu, LoaiSP, 15, 0, 4)
        
        tao_nhan(khung_nhap_lieu, "Tên SP:", 1, 0)
        tao_o_nhap(khung_nhap_lieu, TenSP, 25, 1, 1)

        tao_nhan(khung_nhap_lieu, "Đơn vị:", 1, 3)
        tao_o_nhap(khung_nhap_lieu, DonViTinh, 15, 1, 4)

        tao_nhan(khung_nhap_lieu, "Đơn giá:", 2, 0)
        tao_o_nhap(khung_nhap_lieu, DonGiaBan, 15, 2, 1)

        tao_nhan(khung_nhap_lieu, "Tồn kho:", 2, 3)
        tao_o_nhap(khung_nhap_lieu, TonKho, 15, 2, 4)

        # Nút CRUD
        lenh_nut_chuc_nang = {
            "Thêm": them_sp, "Sửa": sua_sp, "Xoá": xoa_sp,
            "Lưu": luu_sp, "Huỷ": xoa_nhap_lieu, "Thoát": cua_so_con.destroy
        }
        vi_tri_nut = [(0, 7), (1, 7), (2, 7), (0, 8), (1, 8), (2, 8)]
        nhan_nut = ["Thêm", "Sửa", "Xoá", "Lưu", "Huỷ", "Thoát"]

        for nhan, (r, c) in zip(nhan_nut, vi_tri_nut):
            nen_nut = MAU_NUT_NEN if nhan != "Thoát" else MAU_NUT_THOAT
            tk.Button(khung_nhap_lieu, text=nhan, font=FONT_NUT, bg=nen_nut, fg=MAU_CHU_CHINH,
                    relief="flat", width=12, command=lenh_nut_chuc_nang[nhan],
                    activebackground=MAU_NHAN, activeforeground=MAU_NEN_CHINH).grid(row=r, column=c, padx=12, pady=5)

        # Khung tìm kiếm
        khung_tim_kiem = tk.Frame(khung_cha, bg=MAU_NEN_KHUNG)
        khung_tim_kiem.pack(fill='x', padx=20, pady=10)
        tao_nhan(khung_tim_kiem, "Nhập tên SP:", 0, 0)
        tao_o_nhap(khung_tim_kiem, TenSP_TimKiem, 15, 0, 1)
        tk.Button(khung_tim_kiem, text="Tìm kiếm", font=("Segoe UI", 8, "bold"),
                bg=MAU_NUT_NEN, fg=MAU_CHU_CHINH, relief="raised",
                width=10, command=tim_kiem_sp).grid(row=0, column=2, padx=8)
        tk.Button(khung_tim_kiem, text="Hiển thị tất cả", font=("Segoe UI", 8, "bold"),
                bg=MAU_NUT_NEN, fg=MAU_CHU_CHINH, relief="raised",
                width=12, command=hien_thi_tat_ca_sp).grid(row=0, column=3, padx=8)

        # Treeview danh sách sản phẩm
        tk.Label(khung_cha, text="DANH SÁCH SẢN PHẨM", font=FONT_TIEU_DE_NHO, fg=MAU_NHAN, bg=MAU_NEN_CHINH).pack(pady=5)
        for c in cot:
            bang_sp.heading(c, text=c.capitalize())
        bang_sp.column("Mã SP", width=80, anchor="center")
        bang_sp.column("Tên SP", width=150)
        bang_sp.column("Loại SP", width=100)
        bang_sp.column("Đơn vị", width=70, anchor="center")
        bang_sp.column("Đơn giá", width=100, anchor="center")
        bang_sp.column("Tồn kho", width=100, anchor="center")
        bang_sp.pack(padx=20, pady=5, fill="both", expand=True)

        # Load dữ liệu ban đầu
        load_sp()


#===============================================================================
# FORM NHÀ CUNG CẤP
#===============================================================================
    def xay_dung_nhacungcap(khung_cha):
        MaNCC = tk.StringVar()
        TenNCC = tk.StringVar()
        DiaChi = tk.StringVar()
        SDT = tk.StringVar()
        
        TenNCC_TimKiem = tk.StringVar()

        # Khung tiêu đề
        khung_tieu_de = tk.Frame(khung_cha, bg=MAU_NEN_CHINH)
        khung_tieu_de.pack(pady=10, padx=10, fill='x')
        tk.Label(khung_tieu_de, text="TRUNG TÂM ĐỐI TÁC", font=FONT_TIEU_DE_LON, bg=MAU_NEN_CHINH, fg=MAU_NHAN).pack(expand=True,pady=15)

        # Khung nhập liệu
        khung_nhap_lieu = tk.Frame(khung_cha, bg=MAU_NEN_KHUNG)
        khung_nhap_lieu.pack(fill='x', padx=20, pady=10)

        # Treeview
        cot = ("Mã NCC", "Tên NCC", "Địa chỉ", "SĐT")
        bang_ncc = ttk.Treeview(khung_cha, columns=cot, show="headings", height=10)

        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview",
                        background=MAU_NEN_KHUNG,
                        foreground=MAU_CHU_CHINH,
                        fieldbackground=MAU_NEN_KHUNG,
                        rowheight=25)
        style.map('Treeview', background=[('selected', MAU_NUT_NEN)])
        style.configure("Treeview.Heading",
                        background=MAU_NUT_NEN,
                        foreground=MAU_CHU_CHINH,
                        font=('Segoe UI', 10, 'bold'),
                        relief="flat")

        # Hàm tạo nhãn và ô nhập
        def tao_nhan(khung, text, row, col, sticky='w'):
            tk.Label(khung, text=text, font=FONT_NHAN, bg=MAU_NEN_KHUNG, fg=MAU_CHU_CHINH).grid(row=row, column=col, padx=5, pady=5, sticky=sticky)

        def tao_o_nhap(khung, textvariable, width, row, col, sticky='w'):
            tk.Entry(khung, textvariable=textvariable, font=FONT_NHAN, width=width,
                    bg=MAU_NEN_NHAP, fg=MAU_CHU_CHINH, insertbackground=MAU_CHU_CHINH, bd=0).grid(row=row, column=col, padx=5, pady=5, sticky=sticky)

        # ---------- CRUD ----------
        def xoa_nhap_lieu():
            MaNCC.set("")
            TenNCC.set("")
            DiaChi.set("")
            SDT.set("")

        def load_ncc(search_term=None):
            for row in bang_ncc.get_children():
                bang_ncc.delete(row)
            conn = connect()
            if conn is None: return
            try:
                cur = conn.cursor()
                sql = "SELECT MaNCC, TenNCC, DiaChi, SDT FROM NhaCungCap"
                params = []
                if search_term:
                    sql += " WHERE TenNCC LIKE ?"
                    params.append(f'%{search_term}%')
                cur.execute(sql, params)
                for row in cur.fetchall():
                    bang_ncc.insert("", tk.END, values=list(row))
            except Exception as e:
                messagebox.showerror("Lỗi SQL", f"Không thể tải dữ liệu nhà cung cấp:\n{e}")
            finally:
                if conn: conn.close()

        def them_ncc():
            if not all([MaNCC.get(), TenNCC.get()]):
                messagebox.showwarning("Thiếu dữ liệu", "Vui lòng nhập Mã NCC và Tên NCC!")
                return
            conn = connect()
            if conn is None: return
            try:
                cur = conn.cursor()
                cur.execute(
                    "INSERT INTO NhaCungCap (MaNCC, TenNCC, DiaChi, SDT) VALUES (?, ?, ?, ?)",
                    (MaNCC.get(), TenNCC.get(), DiaChi.get(), SDT.get())
                )
                conn.commit()
                load_ncc()
                xoa_nhap_lieu()
                messagebox.showinfo("Thành công", "Đã thêm nhà cung cấp mới.")
            except Exception as e:
                messagebox.showerror("Lỗi", str(e))
            finally:
                conn.close()

        def xoa_ncc():
            selected = bang_ncc.selection()
            if not selected:
                messagebox.showwarning("Chưa chọn", "Hãy chọn dòng để xoá")
                return
            maso = bang_ncc.item(selected[0])["values"][0]
            if not messagebox.askyesno("Xác nhận xoá", f"Bạn có chắc chắn muốn xoá nhà cung cấp mã {maso}?"):
                return
            conn = connect()
            if conn is None: return
            try:
                cur = conn.cursor()
                cur.execute("DELETE FROM NhaCungCap WHERE MaNCC = ?", maso)
                conn.commit()
                load_ncc()
                messagebox.showinfo("Thành công", f"Đã xoá nhà cung cấp mã {maso}.")
            finally:
                conn.close()

        def sua_ncc():
            selected = bang_ncc.selection()
            if not selected:
                messagebox.showwarning("Chưa chọn", "Hãy chọn dòng cần sửa")
                return
            data = bang_ncc.item(selected[0])["values"]
            MaNCC.set(data[0])
            TenNCC.set(data[1])
            DiaChi.set(data[2])
            SDT.set(data[3])
            MaNCC_Entry.config(state='readonly')

        def luu_ncc():
            if not all([MaNCC.get(), TenNCC.get()]):
                messagebox.showwarning("Thiếu dữ liệu", "Vui lòng nhập đầy đủ thông tin!")
                return
            conn = connect()
            if conn is None: return
            try:
                cur = conn.cursor()
                cur.execute("""
                    UPDATE NhaCungCap
                    SET TenNCC=?, DiaChi=?, SDT=?
                    WHERE MaNCC=?
                """, (TenNCC.get(), DiaChi.get(), SDT.get(), MaNCC.get()))
                conn.commit()
                load_ncc()
                xoa_nhap_lieu()
                MaNCC_Entry.config(state='normal')
                messagebox.showinfo("Thành công", f"Đã cập nhật nhà cung cấp mã {MaNCC.get()}.")
            finally:
                conn.close()

        def tim_kiem_ncc():
            search_term = TenNCC_TimKiem.get().strip()
            if not search_term:
                messagebox.showwarning("Tìm kiếm", "Vui lòng nhập tên nhà cung cấp để tìm kiếm.")
                return
            load_ncc(search_term)

        def hien_thi_tat_ca_ncc():
            TenNCC_TimKiem.set("")
            load_ncc()

        # --- Bố cục KHUNG NHẬP LIỆU ---
        tao_nhan(khung_nhap_lieu, "Mã NCC:", 0, 0)
        MaNCC_Entry = tk.Entry(khung_nhap_lieu, textvariable=MaNCC, font=FONT_NHAN, width=20,
                            bg=MAU_NEN_NHAP, fg=MAU_CHU_CHINH, insertbackground=MAU_CHU_CHINH, bd=0)
        MaNCC_Entry.grid(row=0, column=1, padx=5, pady=5, sticky='w')

        tao_nhan(khung_nhap_lieu, "Tên NCC:", 1, 0)
        tao_o_nhap(khung_nhap_lieu, TenNCC, 25, 1, 1)

        tao_nhan(khung_nhap_lieu, "Địa chỉ:", 2, 0)
        tao_o_nhap(khung_nhap_lieu, DiaChi, 25, 2, 1)

        tao_nhan(khung_nhap_lieu, "SĐT:", 3, 0)
        tao_o_nhap(khung_nhap_lieu, SDT, 20, 3, 1)

        # Nút CRUD
        lenh_nut_chuc_nang = {
            "Thêm": them_ncc, "Sửa": sua_ncc, "Xoá": xoa_ncc,
            "Lưu": luu_ncc, "Huỷ": xoa_nhap_lieu, "Thoát": cua_so_con.destroy
        }
        vi_tri_nut = [(0, 3), (1, 3), (2, 3), (0, 4), (1, 4), (2, 4)]
        nhan_nut = ["Thêm", "Sửa", "Xoá", "Lưu", "Huỷ", "Thoát"]

        for nhan, (r, c) in zip(nhan_nut, vi_tri_nut):
            nen_nut = MAU_NUT_NEN if nhan != "Thoát" else MAU_NUT_THOAT
            tk.Button(khung_nhap_lieu, text=nhan, font=FONT_NUT, bg=nen_nut, fg=MAU_CHU_CHINH,
                    relief="flat", width=12, command=lenh_nut_chuc_nang[nhan],
                    activebackground=MAU_NHAN, activeforeground=MAU_NEN_CHINH).grid(row=r, column=c, padx=12, pady=5)

        # Khung tìm kiếm
        khung_tim_kiem = tk.Frame(khung_cha, bg=MAU_NEN_KHUNG)
        khung_tim_kiem.pack(fill='x', padx=20, pady=10)
        tao_nhan(khung_tim_kiem, "Nhập tên NCC:", 0, 0)
        tao_o_nhap(khung_tim_kiem, TenNCC_TimKiem, 20, 0, 1)
        tk.Button(khung_tim_kiem, text="Tìm kiếm", font=("Segoe UI", 8, "bold"),
                bg=MAU_NUT_NEN, fg=MAU_CHU_CHINH, relief="raised",
                width=10, command=tim_kiem_ncc).grid(row=0, column=2, padx=8)
        tk.Button(khung_tim_kiem, text="Hiển thị tất cả", font=("Segoe UI", 8, "bold"),
                bg=MAU_NUT_NEN, fg=MAU_CHU_CHINH, relief="raised",
                width=12, command=hien_thi_tat_ca_ncc).grid(row=0, column=3, padx=8)

        # Treeview danh sách NCC
        tk.Label(khung_cha, text="DANH SÁCH NHÀ CUNG CẤP", font=FONT_TIEU_DE_NHO, fg=MAU_NHAN, bg=MAU_NEN_CHINH).pack(pady=5)
        for c in cot:
            bang_ncc.heading(c, text=c.capitalize())
        bang_ncc.column("Mã NCC", width=100, anchor="center")
        bang_ncc.column("Tên NCC", width=200)
        bang_ncc.column("Địa chỉ", width=200)
        bang_ncc.column("SĐT", width=120, anchor="center")
        bang_ncc.pack(padx=20, pady=5, fill="both", expand=True)

        # Load dữ liệu ban đầu
        load_ncc()


# GỌI HÀM BUILD ĐỂ TẠO NỘI DUNG TRÊN CÁC KHUNG
    xay_dung_nhanvien(noi_dung_nhanvien)
    xay_dung_khachhang(noi_dung_khachhang)
    xay_dung_sanpham(noi_dung_sanpham)
    xay_dung_nhacungcap(noi_dung_ncc)

    dat_trang_thai_hoat_dong(default_page)
    xu_ly_nhan_menu(default_page)
